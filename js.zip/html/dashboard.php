<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Dashboard ASO SBU</title>
  <meta name="description" content="Admin, Dashboard, Bootstrap, Bootstrap 4, Angular, AngularJS" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimal-ui" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">

  <!-- for ios 7 style, multi-resolution icon of 152x152 -->
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-barstyle" content="black-translucent">
  <link rel="apple-touch-icon" href="../assets/images/logo.png">
  <meta name="apple-mobile-web-app-title" content="Flatkit">
  <!-- for Chrome on Android, multi-resolution icon of 196x196 -->
  <meta name="mobile-web-app-capable" content="yes">
  <link rel="shortcut icon" sizes="196x196" href="../assets/images/logo.png">
  
  <!-- style -->
  <link rel="stylesheet" href="../assets/animate.css/animate.min.css" type="text/css" />
  <link rel="stylesheet" href="../assets/glyphicons/glyphicons.css" type="text/css" />
  <link rel="stylesheet" href="../assets/font-awesome/css/font-awesome.min.css" type="text/css" />
  <link rel="stylesheet" href="../assets/material-design-icons/material-design-icons.css" type="text/css" />

  <link rel="stylesheet" href="../assets/bootstrap/dist/css/bootstrap.min.css" type="text/css" />
  <!-- build:css ../assets/styles/app.min.css -->
  <link rel="stylesheet" href="../assets/styles/app.css" type="text/css" />
  <!-- endbuild -->
  <link rel="stylesheet" href="../assets/styles/font.css" type="text/css" />
</head>
<body>
<?php
      $servername = "localhost";
      $username = "root2";
      $password = "1234567890";
      $dbname = "monitoring";
        
      $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $namatabel = "laporan".date("dmY");

        $dcw = mysqli_query($conn, "SELECT SUM(DROP_CORE) FROM $namatabel WHERE DROP_CORE<>'-'");
        while($row = mysqli_fetch_array($dcw)){
          $dc = $row['SUM(DROP_CORE)'];
        }

        $ontw = mysqli_query($conn, "SELECT COUNT(SN_ONT) FROM $namatabel WHERE SN_ONT<>'-'");
        while($row = mysqli_fetch_array($ontw)){
          $ont = $row['COUNT(SN_ONT)'];
        }

        $stbw = mysqli_query($conn, "SELECT COUNT(MAC_STB) FROM $namatabel WHERE MAC_STB<>'-'");
        while($row = mysqli_fetch_array($stbw)){
          $stb = $row['COUNT(MAC_STB)'];
        }

        $mlw = mysqli_query($conn, "SELECT COUNT(MATERIAL_LAIN) FROM $namatabel WHERE MATERIAL_LAIN<>'-'");
        while($row = mysqli_fetch_array($mlw)){
          $ml = $row['COUNT(MATERIAL_LAIN)'];
        }

        $today = "$dc, $ont, $stb, $ml";
        
        $bbe = mysqli_num_rows(mysqli_query($conn, "SELECT TICKET FROM $namatabel WHERE STO = 'BBE'"));
        $gsk = mysqli_num_rows(mysqli_query($conn, "SELECT TICKET FROM $namatabel WHERE STO = 'GSK'"));
        $kbl = mysqli_num_rows(mysqli_query($conn, "SELECT TICKET FROM $namatabel WHERE STO = 'KBL'"));
        $kjr = mysqli_num_rows(mysqli_query($conn, "SELECT TICKET FROM $namatabel WHERE STO = 'KJR'"));
        $kln = mysqli_num_rows(mysqli_query($conn, "SELECT TICKET FROM $namatabel WHERE STO = 'KLN'"));
        $knn = mysqli_num_rows(mysqli_query($conn, "SELECT TICKET FROM $namatabel WHERE STO = 'KNN'"));
        $kps = mysqli_num_rows(mysqli_query($conn, "SELECT TICKET FROM $namatabel WHERE STO = 'KPS'"));
        $krp = mysqli_num_rows(mysqli_query($conn, "SELECT TICKET FROM $namatabel WHERE STO = 'KRP'"));
        $lki = mysqli_num_rows(mysqli_query($conn, "SELECT TICKET FROM $namatabel WHERE STO = 'LKI'"));
        $lmg = mysqli_num_rows(mysqli_query($conn, "SELECT TICKET FROM $namatabel WHERE STO = 'LMG'"));
        $mgo = mysqli_num_rows(mysqli_query($conn, "SELECT TICKET FROM $namatabel WHERE STO = 'mgo'"));
        $tns = mysqli_num_rows(mysqli_query($conn, "SELECT TICKET FROM $namatabel WHERE STO = 'TNS'"));

        $data = ("$bbe, $gsk, $kbl, $kjr, $kln, $knn, $kps, $krp, $lki, $lmg, $mgo, $tns");
      
        $dcbbe = mysqli_query($conn, "SELECT SUM(DROP_CORE) FROM $namatabel WHERE STO='BBE' AND DROP_CORE<>'-'");
        while($row = mysqli_fetch_array($dcbbe)){
          $bbedc = $row['SUM(DROP_CORE)'];
        }
        $dcgsk = mysqli_query($conn, "SELECT SUM(DROP_CORE) FROM $namatabel WHERE STO='GSK' AND DROP_CORE<>'-'");
        while($row = mysqli_fetch_array($dcgsk)){
          $gskdc = $row['SUM(DROP_CORE)'];
        }
        $dckbl = mysqli_query($conn, "SELECT SUM(DROP_CORE) FROM $namatabel WHERE STO='KBL' AND DROP_CORE<>'-'");
        while($row = mysqli_fetch_array($dckbl)){
          $kbldc = $row['SUM(DROP_CORE)'];
        }
        $dckjr = mysqli_query($conn, "SELECT SUM(DROP_CORE) FROM $namatabel WHERE STO='KJR' AND DROP_CORE<>'-'");
        while($row = mysqli_fetch_array($dckjr)){
          $kjrdc = $row['SUM(DROP_CORE)'];
        }
        $dckln = mysqli_query($conn, "SELECT SUM(DROP_CORE) FROM $namatabel WHERE STO='KLN' AND DROP_CORE<>'-'");
        while($row = mysqli_fetch_array($dckln)){
          $klndc = $row['SUM(DROP_CORE)'];
        }
        $dcknn = mysqli_query($conn, "SELECT SUM(DROP_CORE) FROM $namatabel WHERE STO='KNN' AND DROP_CORE<>'-'");
        while($row = mysqli_fetch_array($dcknn)){
          $knndc = $row['SUM(DROP_CORE)'];
        }
        $dckps = mysqli_query($conn, "SELECT SUM(DROP_CORE) FROM $namatabel WHERE STO='KPS' AND DROP_CORE<>'-'");
        while($row = mysqli_fetch_array($dckps)){
          $kpsdc = $row['SUM(DROP_CORE)'];
        }
        $dckrp = mysqli_query($conn, "SELECT SUM(DROP_CORE) FROM $namatabel WHERE STO='KRP' AND DROP_CORE<>'-'");
        while($row = mysqli_fetch_array($dckrp)){
          $krpdc = $row['SUM(DROP_CORE)'];
        }
        $dclki = mysqli_query($conn, "SELECT SUM(DROP_CORE) FROM $namatabel WHERE STO='LKI' AND DROP_CORE<>'-'");
        while($row = mysqli_fetch_array($dclki)){
          $lkidc = $row['SUM(DROP_CORE)'];
        }
        $dclmg = mysqli_query($conn, "SELECT SUM(DROP_CORE) FROM $namatabel WHERE STO='LMG' AND DROP_CORE<>'-'");
        while($row = mysqli_fetch_array($dclmg)){
          $lmgdc = $row['SUM(DROP_CORE)'];
        }
        $dcmgo = mysqli_query($conn, "SELECT SUM(DROP_CORE) FROM $namatabel WHERE STO='MGO' AND DROP_CORE<>'-'");
        while($row = mysqli_fetch_array($dcmgo)){
          $mgodc = $row['SUM(DROP_CORE)'];
        }
        $dctns = mysqli_query($conn, "SELECT SUM(DROP_CORE) FROM $namatabel WHERE STO='TNS' AND DROP_CORE<>'-'");
        while($row = mysqli_fetch_array($dctns)){
          $tnsdc = $row['SUM(DROP_CORE)'];
        }

        $datadc = ("$bbedc, $gskdc, $kbldc, $kjrdc, $klndc, $knndc, $kpsdc, $krpdc, $lkidc, $lmgdc, $mgodc, $tnsdc");

        $bbeont = mysqli_query($conn, "SELECT COUNT(SN_ONT) FROM $namatabel WHERE STO='BBE' AND SN_ONT<>'-'");
        while($row = mysqli_fetch_array($bbeont)){
          $ontbbe = $row['COUNT(SN_ONT)'];
        }
        $gskont = mysqli_query($conn, "SELECT COUNT(SN_ONT) FROM $namatabel WHERE STO='GSK' AND SN_ONT<>'-'");
        while($row = mysqli_fetch_array($gskont)){
          $ontgsk = $row['COUNT(SN_ONT)'];
        }
        $kblont = mysqli_query($conn, "SELECT COUNT(SN_ONT) FROM $namatabel WHERE STO='KBL' AND SN_ONT<>'-'");
        while($row = mysqli_fetch_array($kblont)){
          $ontkbl = $row['COUNT(SN_ONT)'];
        }
        $kjront = mysqli_query($conn, "SELECT COUNT(SN_ONT) FROM $namatabel WHERE STO='KJR' AND SN_ONT<>'-'");
        while($row = mysqli_fetch_array($kjront)){
          $ontkjr = $row['COUNT(SN_ONT)'];
        }
        $klnont = mysqli_query($conn, "SELECT COUNT(SN_ONT) FROM $namatabel WHERE STO='KLN' AND SN_ONT<>'-'");
        while($row = mysqli_fetch_array($klnont)){
          $ontkln = $row['COUNT(SN_ONT)'];
        }
        $knnont = mysqli_query($conn, "SELECT COUNT(SN_ONT) FROM $namatabel WHERE STO='KNN' AND SN_ONT<>'-'");
        while($row = mysqli_fetch_array($knnont)){
          $ontknn = $row['COUNT(SN_ONT)'];
        }
        $kpsont = mysqli_query($conn, "SELECT COUNT(SN_ONT) FROM $namatabel WHERE STO='kps' AND SN_ONT<>'-'");
        while($row = mysqli_fetch_array($kpsont)){
          $ontkps = $row['COUNT(SN_ONT)'];
        }
        $krpont = mysqli_query($conn, "SELECT COUNT(SN_ONT) FROM $namatabel WHERE STO='KRP' AND SN_ONT<>'-'");
        while($row = mysqli_fetch_array($krpont)){
          $ontkrp = $row['COUNT(SN_ONT)'];
        }
        $lkiont = mysqli_query($conn, "SELECT COUNT(SN_ONT) FROM $namatabel WHERE STO='LKI' AND SN_ONT<>'-'");
        while($row = mysqli_fetch_array($lkiont)){
          $ontlki = $row['COUNT(SN_ONT)'];
        }
        $lmgont = mysqli_query($conn, "SELECT COUNT(SN_ONT) FROM $namatabel WHERE STO='LMG' AND SN_ONT<>'-'");
        while($row = mysqli_fetch_array($lmgont)){
          $ontlmg = $row['COUNT(SN_ONT)'];
        }
        $mgoont = mysqli_query($conn, "SELECT COUNT(SN_ONT) FROM $namatabel WHERE STO='MGO' AND SN_ONT<>'-'");
        while($row = mysqli_fetch_array($mgoont)){
          $ontmgo = $row['COUNT(SN_ONT)'];
        }
        $tnsont = mysqli_query($conn, "SELECT COUNT(SN_ONT) FROM $namatabel WHERE STO='TNS' AND SN_ONT<>'-'");
        while($row = mysqli_fetch_array($tnsont)){
          $onttns = $row['COUNT(SN_ONT)'];
        }

        $dataont = ("$ontbbe, $ontgsk, $ontkbl, $ontkjr, $ontkln, $ontknn, $ontkps, $ontkrp, $ontlki, $ontlmg, $ontmgo, $onttns");

        $bbestb = mysqli_query($conn, "SELECT COUNT(MAC_STB) FROM $namatabel WHERE STO='BBE' AND MAC_STB<>'-'");
        while($row = mysqli_fetch_array($bbestb)){
          $stbbbe = $row['COUNT(MAC_STB)'];
        }
        $gskstb = mysqli_query($conn, "SELECT COUNT(MAC_STB) FROM $namatabel WHERE STO='GSK' AND MAC_STB<>'-'");
        while($row = mysqli_fetch_array($gskstb)){
          $stbgsk = $row['COUNT(MAC_STB)'];
        }
        $kblstb = mysqli_query($conn, "SELECT COUNT(MAC_STB) FROM $namatabel WHERE STO='KBL' AND MAC_STB<>'-'");
        while($row = mysqli_fetch_array($kblstb)){
          $stbkbl = $row['COUNT(MAC_STB)'];
        }
        $kjrstb = mysqli_query($conn, "SELECT COUNT(MAC_STB) FROM $namatabel WHERE STO='KJR' AND MAC_STB<>'-'");
        while($row = mysqli_fetch_array($kjrstb)){
          $stbkjr = $row['COUNT(MAC_STB)'];
        }
        $klnstb = mysqli_query($conn, "SELECT COUNT(MAC_STB) FROM $namatabel WHERE STO='KLN' AND MAC_STB<>'-'");
        while($row = mysqli_fetch_array($klnstb)){
          $stbkln = $row['COUNT(MAC_STB)'];
        }
        $knnstb = mysqli_query($conn, "SELECT COUNT(MAC_STB) FROM $namatabel WHERE STO='KNN' AND MAC_STB<>'-'");
        while($row = mysqli_fetch_array($knnstb)){
          $stbknn = $row['COUNT(MAC_STB)'];
        }
        $kpsstb = mysqli_query($conn, "SELECT COUNT(MAC_STB) FROM $namatabel WHERE STO='kps' AND MAC_STB<>'-'");
        while($row = mysqli_fetch_array($kpsstb)){
          $stbkps = $row['COUNT(MAC_STB)'];
        }
        $krpstb = mysqli_query($conn, "SELECT COUNT(MAC_STB) FROM $namatabel WHERE STO='KRP' AND MAC_STB<>'-'");
        while($row = mysqli_fetch_array($krpstb)){
          $stbkrp = $row['COUNT(MAC_STB)'];
        }
        $lkistb = mysqli_query($conn, "SELECT COUNT(MAC_STB) FROM $namatabel WHERE STO='LKI' AND MAC_STB<>'-'");
        while($row = mysqli_fetch_array($lkistb)){
          $stblki = $row['COUNT(MAC_STB)'];
        }
        $lmgstb = mysqli_query($conn, "SELECT COUNT(MAC_STB) FROM $namatabel WHERE STO='LMG' AND MAC_STB<>'-'");
        while($row = mysqli_fetch_array($lmgstb)){
          $stblmg = $row['COUNT(MAC_STB)'];
        }
        $mgostb = mysqli_query($conn, "SELECT COUNT(MAC_STB) FROM $namatabel WHERE STO='MGO' AND MAC_STB<>'-'");
        while($row = mysqli_fetch_array($mgostb)){
          $stbmgo = $row['COUNT(MAC_STB)'];
        }
        $tnsstb = mysqli_query($conn, "SELECT COUNT(MAC_STB) FROM $namatabel WHERE STO='TNS' AND MAC_STB<>'-'");
        while($row = mysqli_fetch_array($tnsstb)){
          $stbtns = $row['COUNT(MAC_STB)'];
        }

        $datastb = ("$stbbbe, $stbgsk, $stbkbl, $stbkjr, $stbkln, $stbknn, $stbkps, $stbkrp, $stblki, $stblmg, $stbmgo, $stbtns");

        $bbeml = mysqli_query($conn, "SELECT COUNT(MATERIAL_LAIN) FROM $namatabel WHERE STO='BBE' AND MATERIAL_LAIN<>'-'");
        while($row = mysqli_fetch_array($bbeml)){
          $mlbbe = $row['COUNT(MATERIAL_LAIN)'];
        }
        $gskml = mysqli_query($conn, "SELECT COUNT(MATERIAL_LAIN) FROM $namatabel WHERE STO='GSK' AND MATERIAL_LAIN<>'-'");
        while($row = mysqli_fetch_array($gskml)){
          $mlgsk = $row['COUNT(MATERIAL_LAIN)'];
        }
        $kblml = mysqli_query($conn, "SELECT COUNT(MATERIAL_LAIN) FROM $namatabel WHERE STO='KBL' AND MATERIAL_LAIN<>'-'");
        while($row = mysqli_fetch_array($kblml)){
          $mlkbl = $row['COUNT(MATERIAL_LAIN)'];
        }
        $kjrml = mysqli_query($conn, "SELECT COUNT(MATERIAL_LAIN) FROM $namatabel WHERE STO='KJR' AND MATERIAL_LAIN<>'-'");
        while($row = mysqli_fetch_array($kjrml)){
          $mlkjr = $row['COUNT(MATERIAL_LAIN)'];
        }
        $klnml = mysqli_query($conn, "SELECT COUNT(MATERIAL_LAIN) FROM $namatabel WHERE STO='KLN' AND MATERIAL_LAIN<>'-'");
        while($row = mysqli_fetch_array($klnml)){
          $mlkln = $row['COUNT(MATERIAL_LAIN)'];
        }
        $knnml = mysqli_query($conn, "SELECT COUNT(MATERIAL_LAIN) FROM $namatabel WHERE STO='KNN' AND MATERIAL_LAIN<>'-'");
        while($row = mysqli_fetch_array($knnml)){
          $mlknn = $row['COUNT(MATERIAL_LAIN)'];
        }
        $kpsml = mysqli_query($conn, "SELECT COUNT(MATERIAL_LAIN) FROM $namatabel WHERE STO='kps' AND MATERIAL_LAIN<>'-'");
        while($row = mysqli_fetch_array($kpsml)){
          $mlkps = $row['COUNT(MATERIAL_LAIN)'];
        }
        $krpml = mysqli_query($conn, "SELECT COUNT(MATERIAL_LAIN) FROM $namatabel WHERE STO='KRP' AND MATERIAL_LAIN<>'-'");
        while($row = mysqli_fetch_array($krpml)){
          $mlkrp = $row['COUNT(MATERIAL_LAIN)'];
        }
        $lkiml = mysqli_query($conn, "SELECT COUNT(MATERIAL_LAIN) FROM $namatabel WHERE STO='LKI' AND MATERIAL_LAIN<>'-'");
        while($row = mysqli_fetch_array($lkiml)){
          $mllki = $row['COUNT(MATERIAL_LAIN)'];
        }
        $lmgml = mysqli_query($conn, "SELECT COUNT(MATERIAL_LAIN) FROM $namatabel WHERE STO='LMG' AND MATERIAL_LAIN<>'-'");
        while($row = mysqli_fetch_array($lmgml)){
          $mllmg = $row['COUNT(MATERIAL_LAIN)'];
        }
        $mgoml = mysqli_query($conn, "SELECT COUNT(MATERIAL_LAIN) FROM $namatabel WHERE STO='MGO' AND MATERIAL_LAIN<>'-'");
        while($row = mysqli_fetch_array($mgoml)){
          $mlmgo = $row['COUNT(MATERIAL_LAIN)'];
        }
        $tnsml = mysqli_query($conn, "SELECT COUNT(MATERIAL_LAIN) FROM $namatabel WHERE STO='TNS' AND MATERIAL_LAIN<>'-'");
        while($row = mysqli_fetch_array($tnsml)){
          $mltns = $row['COUNT(MATERIAL_LAIN)'];
        }

        $dataml = ("$mlbbe, $mlgsk, $mlkbl, $mlkjr, $mlkln, $mlknn, $mlkps, $mlkrp, $mllki, $mllmg, $mlmgo, $mltns");

?>
  <div class="app" id="app">

<!-- ############ LAYOUT START-->

  <!-- aside -->
  <div id="aside" class="app-aside modal fade nav-dropdown">
  	<!-- fluid app aside -->
    <div class="left navside dark dk" layout="column">
  	  <div class="navbar no-radius">
        <!-- brand -->
        <a class="navbar-brand">
        	<div ui-include="'../assets/images/logo.svg'"></div>
        	<img src="../assets/images/logo.png" alt="." class="hide">
        	<span class="hidden-folded inline">ASO SBU</span>
        </a>
        <!-- / brand -->
      </div>
      <div flex class="hide-scroll">
          <nav class="scroll nav-light">
            
              <ul class="nav" ui-nav>
                <li class="nav-header hidden-folded">
                  <small class="text-muted">Main</small>
                </li>
                
                <li>
                  <a href="dashboard.php" >
                    <span class="nav-icon">
                      <i class="material-icons">&#xe3fc;
                        <span ui-include="'../assets/images/i_0.svg'"></span>
                      </i>
                    </span>
                    <span class="nav-text">Dashboard</span>
                  </a>
                </li>
            
                <li>
                  <a href="static.html" >
                    <span class="nav-icon">
                      <i class="material-icons">&#xe8f0;
                        <span ui-include="'../assets/images/i_3.svg'"></span>
                      </i>
                    </span>
                    <span class="nav-text">Tabel</span>
                  </a>
                </li>
                <li>
                  <a href="calendar.html" >
                    <span class="nav-icon">
                      <i class="material-icons">&#xe8a3;
                        <span ui-include="'../assets/images/i_3.svg'"></span>
                      </i>
                    </span>
                    <span class="nav-text">Kalender</span>
                  </a>
                </li>
                
                <li>
                  <a>
                    <span class="nav-caret">
                      <i class="fa fa-caret-down"></i>
                    </span>
                    <span class="nav-label hidden-folded">
                      <b class="label label-sm info">N</b>
                    </span>
                    <span class="nav-icon">
                      <i class="material-icons">&#xe1b8;
                        <span ui-include="'../assets/images/i_8.svg'"></span>
                      </i>
                    </span>
                    <span class="nav-text">STO</span>
                  </a>
                  <ul class="nav-sub">
                    <li>
                      <a href="chart.html" >
                        <span class="nav-text">MGO</span>
                      </a>
                    </li>
                    <li>
                      <a href="chart.html" >
                        <span class="nav-text">GSK</span>
                      </a>
                    </li><li>
                      <a href="chart.html" >
                        <span class="nav-text">TNS</span>
                      </a>
                    </li>
                    <li>
                      <a href="chart.html" >
                        <span class="nav-text">KNN</span>
                      </a>
                    </li>
                    <li>
                      <a href="chart.html" >
                        <span class="nav-text">KRP</span>
                      </a>
                    </li>
                    <li>
                      <a href="chart.html" >
                        <span class="nav-text">BBE</span>
                      </a>
                    </li>
                    <li>
                      <a href="chart.html" >
                        <span class="nav-text">KJR</span>
                      </a>
                    </li>
                    <li>
                      <a href="chart.html" >
                        <span class="nav-text">KBL</span>
                      </a>
                    </li>
                    <li>
                      <a href="chart.html" >
                        <span class="nav-text">LKI</span>
                      </a>
                    </li>
                    <li>
                      <a href="chart.html" >
                        <span class="nav-text">KLN</span>
                      </a>
                    </li>
                    <li>
                      <a href="chart.html" >
                        <span class="nav-text">LMG</span>
                      </a>
                    </li>
                    <li>
                      <a href="chart.html" >
                        <span class="nav-text">KPS</span>
                      </a>
                    </li>
                  
                  </ul>
                </li>            
              </ul>
          </nav>
      </div>
      <div flex-no-shrink class="b-t">
        <div class="nav-fold">
        	<a href="profile.html">
        	    <span class="pull-left">
        	      <img src="../assets/images/a0.jpg" alt="..." class="w-40 img-circle">
        	    </span>
        	    <span class="clear hidden-folded p-x">
        	      <span class="block _500">Jean Reyes</span>
        	      <small class="block text-muted"><i class="fa fa-circle text-success m-r-sm"></i>online</small>
        	    </span>
        	</a>
        </div>
      </div>
    </div>
  </div>
  <!-- / -->
  
  <!-- content -->
  <div id="content" class="app-content box-shadow-z0" role="main">
    <div class="app-header white box-shadow">
        <div class="navbar">
            <!-- Open side - Naviation on mobile -->
            <a data-toggle="modal" data-target="#aside" class="navbar-item pull-left hidden-lg-up">
              <i class="material-icons">&#xe5d2;</i>
            </a>
            <!-- / -->
        
            <!-- Page title - Bind to $state's title -->
            <div class="navbar-item pull-left h5" ng-bind="$state.current.data.title" id="pageTitle"></div>
        
            <!-- navbar right -->
            <ul class="nav navbar-nav pull-right">
              <li class="nav-item dropdown pos-stc-xs">
                <a class="nav-link" href data-toggle="dropdown">
                  <i class="material-icons">&#xe7f5;</i>
                  <span class="label label-sm up warn">3</span>
                </a>
                <div ui-include="'../views/blocks/dropdown.notification.html'"></div>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link clear" href data-toggle="dropdown">
                  <span class="avatar w-32">
                    <img src="../assets/images/a0.jpg" alt="...">
                    <i class="on b-white bottom"></i>
                  </span>
                </a>
                <div ui-include="'../views/blocks/dropdown.user.html'"></div>
              </li>
              <li class="nav-item hidden-md-up">
                <a class="nav-link" data-toggle="collapse" data-target="#collapse">
                  <i class="material-icons">&#xe5d4;</i>
                </a>
              </li>
            </ul>
            <!-- / navbar right -->
            <!-- / navbar collapse -->
        </div>
    </div>
    <div class="app-footer">
      <div class="p-a text-xs">
        <div class="pull-right text-muted">
          &copy; Developed by <strong>Brian Barella</strong> <span class="hidden-xs-down">- Built with Love</span>
          <a ui-scroll-to="content"><i class="fa fa-long-arrow-up p-x-sm"></i></a>
        </div>
      </div>
    </div>
    <div ui-view class="app-body" id="view">

<!-- ############ PAGE START-->
<div class="p-a white lt box-shadow">
	<div class="row">
		<div class="col-sm-6">
			<h4 class="m-b-0 _300">Dashboard</h4>
			<small class="text-muted">Monitoring <strong></strong> Material Gangguan</small>
		</div>
	</div>
</div>
<div class="padding">
	<div class="row">
		<div class="col-xs-12 col-sm-4">
	        <div class="box p-a">
	          <div class="pull-left m-r">
	            <span class="w-48 rounded  warning">
	              <i class="material-icons">&#xe0d9;</i>
	            </span>
	          </div>
	          <div class="clear">
	            <h4 class="m-a-0 text-lg _300"><a href>125 <span class="text-sm">Drop Core</span></a></h4>
	            <small class="text-muted">meter</small>
	          </div>
	        </div>
	  </div>
    <div class="col-xs-12 col-sm-4">
      <div class="box p-a">
        <div class="pull-left m-r">
          <span class="w-48 rounded danger">
            <i class="material-icons">&#xe1e2;</i>
          </span>
        </div>
        <div class="clear">
          <h4 class="m-a-0 text-lg _300"><a href>125 <span class="text-sm">ONT</span></a></h4>
          <small class="text-muted">Buah</small>
        </div>
      </div>
  </div>	    
	    <div class="col-xs-6 col-sm-4">
	        <div class="box p-a">
	          <div class="pull-left m-r">
	            <span class="w-48 rounded info">
	              <i class="material-icons">&#xe039;</i>
	            </span>
	          </div>
	          <div class="clear">
	            <h4 class="m-a-0 text-lg _300"><a href>600 <span class="text-sm">STB</span></a></h4>
	            <small class="text-muted">Buah</small>
	          </div>
	        </div>
	    </div>
    <div class="col-xs-12 col-sm-4">
      <div class="box p-a">
        <div class="pull-left m-r">
          <span class="w-48 rounded text-center success">
            <i class="material-icons">&#xe39d;</i>
          </span>
        </div>
        <div class="clear">
          <h4 class="m-a-0 text-lg _300"><a href>125 <span class="text-sm">Material Lain</span></a></h4>
          <small class="text-muted">Buah</small>
        </div>
      </div>
  </div>
    <div class="col-xs-6 col-sm-4">
        <div class="box p-a">
          <div class="pull-left m-r">
            <span class="w-48 rounded warn">
              <i class="material-icons">&#xe862;</i>
            </span>
          </div>
          <div class="clear">
            <h4 class="m-a-0 text-lg _300"><a href>40 <span class="text-sm">Ticket Selesai</span></a></h4>
            <small class="text-muted">Buah</small>
          </div>
        </div>
    </div>
    <div class="col-xs-12 col-sm-4">
    <div class="box p-a">
        <div class="pull-left m-r">
          <span class="w-48 rounded  accent">
            <i class="material-icons">&#xe861;</i>
          </span>
        </div>
        <div class="clear">
          <h4 class="m-a-0 text-lg _300"><a href>125 <span class="text-sm">Masuk Database</span></a></h4>
          <small class="text-muted">Buah</small>
        </div>
      </div>
  </div>
</div>
	<div class="row">
		<div class="col-sm-6">
      <div class="box">
        <div class="box-header">
          <h3>Penggunaan Tiap Material</h3>
          <small class="block text-muted">Di Witel SBU</small>
        </div>
        <div class="box-body">
          <div ui-jp="chart" ui-options="{
              tooltip : {
                  trigger: 'axis'
              },
              legend: {
                  data:['Drop Core','ONT','STB']
              },
              calculable : true,
              xAxis : [
                  {
                      type : 'category',
                      boundaryGap : false,
                      data : ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']
                  }
              ],
              yAxis : [
                  {
                      type : 'value'
                  }
              ],
              series : [
                  {
                      name:'Drop Core',
                      type:'line',
                      smooth:true,
                      itemStyle: {normal: {areaStyle: {type: 'default'}}},
                      data:[1, 1, 1, 1, 1, 1, <?php print_r($dc);?>]
                  },
                  {
                      name:'ONT',
                      type:'line',
                      smooth:true,
                      itemStyle: {normal: {areaStyle: {type: 'default'}}},
                      data:[1, 1, 1, 1, 1, 1, <?php print_r($ont);?>]
                  },
                  {
                      name:'STB',
                      type:'line',
                      smooth:true,
                      itemStyle: {normal: {areaStyle: {type: 'default'}}},
                      data:[1, 1, 1, 1, 1, 1, <?php print_r($stb);?>]
                  }
              ]
                  
          }" style="height:300px" >
          </div>
        </div>
      </div>
    </div>
    <div class="col-sm-6">
        <div class="box">
          <div class="box-header">
            <h3>Ticket Gangguan Selesai Tiap STO</h3>
            <small class="block text-muted">Di Witel SBU</small>
          </div>
          <div class="box-body">
            <div ui-jp="chart" ui-options="{
               tooltip: {
                  trigger: 'item'
              },
              calculable: true,
              grid: {
                  borderWidth: 0
              },
              xAxis: [
                  {
                      type: 'category',
                      show: false,
                      data: ['BBE', 'GSK', 'KBL', 'KJR', 'KLN', 'KNN', 'KPS', 'KRP', 'LKI', 'LMG', 'MGO', 'TNS']
                  }
              ],
              yAxis: [
                  {
                      type: 'value',
                      show: false
                  }
              ],
              series: [
                  {
                      name: 'Echarts Samples',
                      type: 'bar',
                      itemStyle: {
                          normal: {
                              color: function(params) {
                                  var colorList = [
                                    '#C1232B','#B5C334','#FCCE10','#E87C25','#27727B',
                                     '#FE8463','#9BCA63','#FAD860','#F3A43B','#60C0DD',
                                     '#D7504B','#C6E579','#F4E001','#F0805A','#26C0C0'
                                  ];
                                  return colorList[params.dataIndex]
                              },
                              label: {
                                  show: true,
                                  position: 'top',
                                  formatter: '{b}\n{c}'
                              }
                          }
                      },
                      data: [<?php print_r($data);?>]
                  }
              ]
            }" style="height:300px" >
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-6">
        <div class="box">
          <div class="box-header">
            <h3>Penggunaan Material Drop Core Tiap STO</h3>
            <small class="block text-muted">Di Witel SBU</small>
          </div>
          <div class="box-body">
            <div ui-jp="chart" ui-options="{
               tooltip: {
                  trigger: 'item'
              },
              calculable: true,
              grid: {
                  borderWidth: 0
              },
              xAxis: [
                  {
                      type: 'category',
                      show: false,
                      data: ['BBE', 'GSK', 'KBL', 'KJR', 'KLN', 'KNN', 'KPS', 'KRP', 'LKI', 'LMG', 'MGO', 'TNS']
                  }
              ],
              yAxis: [
                  {
                      type: 'value',
                      show: false
                  }
              ],
              series: [
                  {
                      name: 'Echarts Samples',
                      type: 'bar',
                      itemStyle: {
                          normal: {
                              color: function(params) {
                                  var colorList = [
                                    '#C1232B','#B5C334','#FCCE10','#E87C25','#27727B',
                                     '#FE8463','#9BCA63','#FAD860','#F3A43B','#60C0DD',
                                     '#D7504B','#C6E579','#F4E001','#F0805A','#26C0C0'
                                  ];
                                  return colorList[params.dataIndex]
                              },
                              label: {
                                  show: true,
                                  position: 'top',
                                  formatter: '{b}\n{c}'
                              }
                          }
                      },
                      data: [<?php print_r($datadc);?>]
                  }
              ]
            }" style="height:300px" >
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-6">
        <div class="box">
          <div class="box-header">
            <h3>Penggunaan Material ONT Tiap STO</h3>
            <small class="block text-muted">Di Witel SBU</small>
          </div>
          <div class="box-body">
            <div ui-jp="chart" ui-options="{
               tooltip: {
                  trigger: 'item'
              },
              calculable: true,
              grid: {
                  borderWidth: 0
              },
              xAxis: [
                  {
                      type: 'category',
                      show: false,
                      data: ['BBE', 'GSK', 'KBL', 'KJR', 'KLN', 'KNN', 'KPS', 'KRP', 'LKI', 'LMG', 'MGO', 'TNS']
                  }
              ],
              yAxis: [
                  {
                      type: 'value',
                      show: false
                  }
              ],
              series: [
                  {
                      name: 'Echarts Samples',
                      type: 'bar',
                      itemStyle: {
                          normal: {
                              color: function(params) {
                                  var colorList = [
                                    '#C1232B','#B5C334','#FCCE10','#E87C25','#27727B',
                                     '#FE8463','#9BCA63','#FAD860','#F3A43B','#60C0DD',
                                     '#D7504B','#C6E579','#F4E001','#F0805A','#26C0C0'
                                  ];
                                  return colorList[params.dataIndex]
                              },
                              label: {
                                  show: true,
                                  position: 'top',
                                  formatter: '{b}\n{c}'
                              }
                          }
                      },
                      data: [<?php print_r($dataont);?>]
                  }
              ]
            }" style="height:300px" >
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-6">
        <div class="box">
          <div class="box-header">
            <h3>Penggunaan Material STB Tiap STO</h3>
            <small class="block text-muted">Di Witel SBU</small>
          </div>
          <div class="box-body">
            <div ui-jp="chart" ui-options="{
               tooltip: {
                  trigger: 'item'
              },
              calculable: true,
              grid: {
                  borderWidth: 0
              },
              xAxis: [
                  {
                      type: 'category',
                      show: false,
                      data: ['BBE', 'GSK', 'KBL', 'KJR', 'KLN', 'KNN', 'KPS', 'KRP', 'LKI', 'LMG', 'MGO', 'TNS']
                  }
              ],
              yAxis: [
                  {
                      type: 'value',
                      show: false
                  }
              ],
              series: [
                  {
                      name: 'Echarts Samples',
                      type: 'bar',
                      itemStyle: {
                          normal: {
                              color: function(params) {
                                  var colorList = [
                                    '#C1232B','#B5C334','#FCCE10','#E87C25','#27727B',
                                     '#FE8463','#9BCA63','#FAD860','#F3A43B','#60C0DD',
                                     '#D7504B','#C6E579','#F4E001','#F0805A','#26C0C0'
                                  ];
                                  return colorList[params.dataIndex]
                              },
                              label: {
                                  show: true,
                                  position: 'top',
                                  formatter: '{b}\n{c}'
                              }
                          }
                      },
                      data: [<?php print_r($datastb);?>]
                  }
              ]
            }" style="height:300px" >
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-6">
        <div class="box">
          <div class="box-header">
            <h3>Penggunaan Material Lain Tiap STO</h3>
            <small class="block text-muted">Di Witel SBU</small>
          </div>
          <div class="box-body">
            <div ui-jp="chart" ui-options="{
               tooltip: {
                  trigger: 'item'
              },
              calculable: true,
              grid: {
                  borderWidth: 0
              },
              xAxis: [
                  {
                      type: 'category',
                      show: false,
                      data: ['BBE', 'GSK', 'KBL', 'KJR', 'KLN', 'KNN', 'KPS', 'KRP', 'LKI', 'LMG', 'MGO', 'TNS']
                  }
              ],
              yAxis: [
                  {
                      type: 'value',
                      show: false
                  }
              ],
              series: [
                  {
                      name: 'Echarts Samples',
                      type: 'bar',
                      itemStyle: {
                          normal: {
                              color: function(params) {
                                  var colorList = [
                                    '#C1232B','#B5C334','#FCCE10','#E87C25','#27727B',
                                     '#FE8463','#9BCA63','#FAD860','#F3A43B','#60C0DD',
                                     '#D7504B','#C6E579','#F4E001','#F0805A','#26C0C0'
                                  ];
                                  return colorList[params.dataIndex]
                              },
                              label: {
                                  show: true,
                                  position: 'top',
                                  formatter: '{b}\n{c}'
                              }
                          }
                      },
                      data: [<?php print_r($dataml);?>]
                  }
              ]
            }" style="height:300px" >
            </div>
          </div>
        </div>
      </div>
	</div>
</div>

<!-- ############ PAGE END-->

    </div>
  </div>
  <!-- / -->

  <!-- theme switcher -->
  <div id="switcher">
    <div class="switcher box-color dark-white text-color" id="sw-theme">
      <a href ui-toggle-class="active" target="#sw-theme" class="box-color warn text-color sw-btn">
        <i class="fa fa-gear"></i>
      </a>
      <div class="box-header">
        <h2>Theme Switcher</h2>
      </div>
      <div class="box-divider"></div>
      <div class="box-body">  
        <div data-target="bg" class="text-u-c text-center _600 clearfix">
          <label class="p-a col-xs-6 light pointer m-a-0">
            <input type="radio" name="theme" value="" hidden>
            Light
          </label>
          <label class="p-a col-xs-6 black pointer m-a-0">
            <input type="radio" name="theme" value="black" hidden>
            Dark
          </label>
        </div>
      </div>
    </div>
  </div>
  <!-- / -->

<!-- ############ LAYOUT END-->

  </div>
<!-- build:js scripts/app.html.js -->
<!-- jQuery -->
  <script src="../libs/jquery/jquery/dist/jquery.js"></script>
<!-- Bootstrap -->
  <script src="../libs/jquery/tether/dist/js/tether.min.js"></script>
  <script src="../libs/jquery/bootstrap/dist/js/bootstrap.js"></script>
<!-- core -->
  <script src="../libs/jquery/underscore/underscore-min.js"></script>
  <script src="../libs/jquery/jQuery-Storage-API/jquery.storageapi.min.js"></script>
  <script src="../libs/jquery/PACE/pace.min.js"></script>

  <script src="scripts/config.lazyload.js"></script>

  <script src="scripts/palette.js"></script>
  <script src="scripts/ui-load.js"></script>
  <script src="scripts/ui-jp.js"></script>
  <script src="scripts/ui-include.js"></script>
  <script src="scripts/ui-device.js"></script>
  <script src="scripts/ui-form.js"></script>
  <script src="scripts/ui-nav.js"></script>
  <script src="scripts/ui-screenfull.js"></script>
  <script src="scripts/ui-scroll-to.js"></script>
  <script src="scripts/ui-toggle-class.js"></script>

  <script src="scripts/app.js"></script>

  <!-- ajax -->
  <script src="../libs/jquery/jquery-pjax/jquery.pjax.js"></script>
  <script src="scripts/ajax.js"></script>
<!-- endbuild -->
</body>
</html>
