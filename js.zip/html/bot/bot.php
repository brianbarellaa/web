<?php
$token = "1118438602:AAHmDayZFRk3dCDDpkxEuitF9biy1rpBgho"; //Ganti dengan Token yang diperoleh dari BotFather
$usernamebot="@AssuranceSBUbot"; //nama bot yang diperoleh dari BotFather
define('BOT_TOKEN', $token); 

define('API_URL', 'https://api.telegram.org/bot'.BOT_TOKEN.'/');
define('GET_URL', 'https://api.telegram.org/file/bot'.BOT_TOKEN.'/');
                                
function exec_curl_request($handle)
{
    $response = curl_exec($handle);

    if ($response === false) {
        $errno = curl_errno($handle);
        $error = curl_error($handle);
        error_log("Curl returned error $errno: $error\n");
        curl_close($handle);

        return false;
    }

    $http_code = intval(curl_getinfo($handle, CURLINFO_HTTP_CODE));
    curl_close($handle);

    if ($http_code >= 500) {
        // do not wat to DDOS server if something goes wrong
    sleep(10);

        return false;
    } elseif ($http_code != 200) {
        $response = json_decode($response, true);
        error_log("Request has failed with error {$response['error_code']}: {$response['description']}\n");
        if ($http_code == 401) {
            throw new Exception('Invalid access token provided');
        }

        return false;
    } else {
        $response = json_decode($response, true);
        if (isset($response['description'])) {
            error_log("Request was successfull: {$response['description']}\n");
        }
        $response = $response['result'];
    }

    return $response;
}

function apiRequest($method, $parameters){
    if (!is_string($method)) {
        error_log("Method name must be a string\n");

        return false;
    }

    if (!$parameters) {
        $parameters = [];
    } elseif (!is_array($parameters)) {
        error_log("Parameters must be an array\n");

        return false;
    }

    foreach ($parameters as $key => &$val) {
        // encoding to JSON array parameters, for example reply_markup
    if (!is_numeric($val) && !is_string($val)) {
        $val = json_encode($val);
    }
    }
    $url = API_URL.$method.'?'.http_build_query($parameters);

    $handle = curl_init($url);
    curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($handle, CURLOPT_CONNECTTIMEOUT, 5);
    curl_setopt($handle, CURLOPT_TIMEOUT, 60);
    curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);

    return exec_curl_request($handle);
}

function apiRequestJson($method, $parameters)
{
    if (!is_string($method)) {
        error_log("Method name must be a string\n");

        return false;
    }

    if (!$parameters) {
        $parameters = [];
    } elseif (!is_array($parameters)) {
        error_log("Parameters must be an array\n");

        return false;
    }

    $parameters['method'] = $method;

    $handle = curl_init(API_URL);
    curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($handle, CURLOPT_CONNECTTIMEOUT, 5);
    curl_setopt($handle, CURLOPT_TIMEOUT, 60);
    curl_setopt($handle, CURLOPT_POSTFIELDS, json_encode($parameters));
    curl_setopt($handle, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

    return exec_curl_request($handle);
}

// jebakan token, klo ga diisi akan mati
if (strlen(BOT_TOKEN) < 20) {
    die(PHP_EOL."-> -> Token BOT API nya mohon diisi dengan benar!\n");
}

function getUpdates($last_id = null)
{
    $params = [];
    if (!empty($last_id)) {
        $params = ['offset' => $last_id + 1, 'limit' => 1];
    }
  //echo print_r($params, true);
  return apiRequest('getUpdates', $params);
}

function apigetFilePath($method, $gambar){
    $data = $gambar;
    $bot_url = (API_URL);
    $url = $bot_url . $method . "?file_id=" . $data ;
    $ch = curl_init();  
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  
    $out = curl_exec($ch); 
    curl_close($ch);
    $path = json_decode($out, true);
    $filepath = [$path]["0"]["result"]["file_path"];    
    return apigetFile('getFile', $filepath, $gambar);
}

function apigetFile($method, $filepath, $gambar){
    $data = $filepath;
    $pecah4 = explode('/', $data, 2);
    $namake1 = strtolower($pecah4[1]);
    $bot_url = (GET_URL);
    $url = $bot_url . $data;

    $dir = dirname(__FILE__);
    $parent = explode("/", $dir, 3);
    $parentdir = strtolower($parent[1]);

    set_time_limit(0);
    $fp = fopen ($namake1, 'x');
    $ch = curl_init(str_replace(" ","%20",$url));

    curl_setopt($ch, CURLOPT_TIMEOUT, 50);

    curl_setopt($ch, CURLOPT_FILE, $fp);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

    $data1 = curl_exec($ch);//get curl response


    curl_close($ch);

    exec("cd /$parentdir");

    $tahun = date("Y");
    $bulan = date("m");
    $tgl = date("d");

    $folderth = "/$parentdir/$tahun";
    $foldermo = "/$parentdir/$tahun/$bulan";
    $folderda = "/$parentdir/$tahun/$bulan/$tgl";
    
    if(file_exists($folderth)){
        exec("cd $folderth");
        if(file_exists($foldermo)){
            exec("cd $foldermo");
            if(file_exists($folderda)){
                exec("cd $folderda");  
                exec("mv /$parentdir/bot/$namake1 /$parentdir/$tahun/$bulan/$tgl");             
            } else {
                exec("mkdir $folderda");
                exec("cd $folderda");
                exec("mv /$parentdir/bot/$namake1 /$parentdir/$tahun/$bulan/$tgl");
            }
        } else {
                exec("mkdir $foldermo");
                exec("cd $foldermo");
                exec("mkdir $folderda");
                exec("cd $folderda");  
                exec("mv /$parentdir/bot/$namake1 /$parentdir/$tahun/$bulan/$tgl");             
            } 
    } else {
            exec("mkdir $folderth");
            exec("cd $folderth");
            exec("mkdir $foldermo");
            exec("cd $foldermo");
            exec("mkdir $folderda");
            exec("cd $folderda");  
            exec("mv /$parentdir/bot/$namake1 /$parentdir/$tahun/$bulan/$tgl");             
    }
    $servername = "localhost";
    $username = "root";
    $password = "1234567890";
    $dbname = "monitoring";
    
    $namatabel = "Laporan".date("dmY");

    $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

    $evi = "update $namatabel set EVIDENCE='$namake1' where EVIDENCE='$gambar'";
    if ($conn->query($evi) === TRUE) {
        echo "New record and evidence added succcessfully";
    } else {
        echo "Error: " . $evi . $conn->error;
    }
}

// ----------- pantengin mulai ini
function sendMessage($idpesan, $idchat, $pesan){
    $data = [
    'chat_id'             => $idchat,
    'text'                => $pesan,
    'parse_mode'          => 'html',
    'send_to_message_id' => $idpesan
  ];

    return apiRequest('sendMessage', $data);
}

function sendKeyboard($idpesan, $idchat, $pesan, $keyboard){
    $data = [
    'chat_id'             => $idchat,
    'text'                => $pesan,
    'parse_mode'          => 'html',
    'send_to_message_id' => $idpesan,
    'reply_markup'       => $keyboard,
  ];

    return apiRequest('sendMessage', $data);
}

function apiRequestMedia($method, $idchat, $data) {
    $chat_id = $idchat;
    $bot_url = (API_URL);
    $url = $bot_url . $method . "?chat_id=" . $chat_id ;
    $ch = curl_init(); 
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        "Content-Type:multipart/form-data"
    ));
    curl_setopt($ch, CURLOPT_URL, $url); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data); 
    $output = curl_exec($ch);
}

function prosesCallBackQuery($message)
{
    // if ($GLOBALS['debug']) mypre($message);

    $idpesan = $message['message']['message_id'];
    $idchat = $message['message']['chat']['id'];
    $data = $message['data'];

    $inline_button1 = array("text"=>"Help","callback_data"=>'/help');
    $inline_button2 = array("text"=>"Format","callback_data"=>'/format');
    $inline_button3 = array("text"=>"Laporan","callback_data"=>'laporan');
    $inline_button4 = array("text"=>"Download","callback_data"=>'/download');
    $inline_keyboard = [[$inline_button1,$inline_button2],[$inline_button3,$inline_button4]];
    $keyboard=array("inline_keyboard"=>$inline_keyboard);

    $text = '*'.date('H:i:s').'* data baru : '.$data;

    editMessageText($idchat, $idpesan, $text, $keyboard, true);

    $messageupdate = $message['message'];
    $messageupdate['text'] = $data;

    prosesMessage($messageupdate);
}

function editMessageText($idchat, $idpesan, $text, $keyboard = [], $inline = false)
{
    $method = 'editMessageText';
    
    $data = [
        'chat_id'    => $idchat,
        'message_id' => $idpesan,
        'text'       => $text,
        'parse_mode' => 'html',
        'reply_markup'  => $keyboard,

    ];

    $result = apiRequest($method, $data);
}

function processMessage($message){
    global $database;
    if ($GLOBALS['debug']) {
        //print_r($caption);
    }

    $dir = dirname(__FILE__);
    $parent = explode("/", $dir, 3);
    $parentdir = strtolower($parent[1]);

    $jam = date("H");
    if ($jam == 24);{
        $servername = "localhost";
        $username = "root";
        $password = "1234567890";
        $dbname = "monitoring";
            
        $conn = new mysqli($servername, $username, $password, $dbname);
            if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $dir = dirname(__FILE__);
        $parent = explode("/", $dir, 3);
        $parentdir = strtolower($parent[1]);

        $tahun = date("Y");
        $bulan = date("m");
        $tgl = date("d");
        $kemarin = date("d")-1;

        $namatabel1 = "Laporan".$kemarin.$bulan.$tahun;
        
        $filefix = "Laporan-".$kemarin."-".$bulan."-".$tahun.".xlsx";
        $file = "Laporan-".$kemarin."-".$bulan."-".$tahun.".zip";
        $lap = "Laporan.xlsx";
        
        exec("php -f export-to-excel.php");

        $folderth = "/$parentdir/$tahun";
        $foldermo = "/$parentdir/$tahun/$bulan";
        $folderda = "/$parentdir/$tahun/$bulan/$kemarin";

        if(file_exists($folderth)){
            exec("cd $folderth");
            if(file_exists($foldermo)){
                exec("cd $foldermo");
                if(file_exists($folderda)){
                    exec("cd $folderda");               
                } else {
                    exec("mkdir $folderda");
                    exec("cd $folderda");
                }
            } else {
                exec("mkdir $foldermo");
                exec("cd $foldermo");
                exec("mkdir $folderda");
                exec("cd $folderda");               
            } 
        } else {
            exec("mkdir $folderth");
            exec("cd $folderth");
            exec("mkdir $foldermo");
            exec("cd $foldermo");
            exec("mkdir $folderda");
            exec("cd $folderda");               
        }

        exec("mv /$parentdir/bot/$lap /$parentdir/$tahun/$bulan/$kemarin/$filefix");
        exec("zip -r $file $folderda");

        $folderb = "/$parentdir/Backup";
        $folderbth = "/$parentdir/Backup/$tahun";
        $folderbmo = "/$parentdir/Backup/$tahun/$bulan";
        
        if(file_exists($folderb)){
            exec("cd $folderb");
            if(file_exists($folderbth)){
                exec("cd $folderbth");
                if(file_exists($folderbmo)){
                    exec("cd $folderbmo");               
                } else {
                    exec("mkdir $folderbmo");
                    exec("cd $folderbmo");
                }
            } else {
                exec("mkdir $folderbth");
                exec("cd $folderbth");
                exec("mkdir $folderbmo");
                exec("cd $folderbmo");               
            } 
        } else {
            exec("mkdir $folderb");
            exec("cd $folderb");
            exec("mkdir $folderbth");
            exec("cd $folderbth");
            exec("mkdir $folderbmo");
            exec("cd $folderbmo");               
        }

        exec("mv /$parentdir/bot/$file $folderbmo");
    
        $namatabel = "Laporan".date("dmY");
        $buattabel = "create table $namatabel (
            NOMOR INT NOT NULL AUTO_INCREMENT,
            STO VARCHAR(3),
            CREW VARCHAR(255),
            TICKET VARCHAR(255),
            LAYANAN VARCHAR(255),
            CP_PELANGGAN VARCHAR(255),
            NO_PELANGGAN VARCHAR(255),
            DROP_CORE VARCHAR(4),
            SN_ONT VARCHAR(255),
            MAC_STB VARCHAR(255),
            MATERIAL_LAIN VARCHAR(255),
            JUMLAH VARCHAR(255),
            EVIDENCE VARCHAR(255),
            PRIMARY KEY(NOMOR)
        )";
        $laksanakan = mysqli_query($conn, $buattabel);
    }

    if (isset($message['message'])) {
            
        $sumber = $message['message'];
        $idpesan = $sumber['message_id'];
        $idchat = $sumber['chat']['id'];

        $photo = [];

        $caption2 = $message['message']['caption'];
        $pesan = $sumber['text'];
        $gambar = $sumber["photo"]["1"]["file_id"];
        $caption = str_replace("\n", " ", $caption2);
        
        $username = $sumber["from"]["username"];
        $nama = $sumber['from']['first_name'];
        $iduser = $sumber['from']['id'];

        print_r($pesan);
        print_r($caption2);
        print_r($caption);

        $pecah = explode(' ', $pesan, 2);
        $katapertama = strtolower($pecah[0]);
        $katakedua = strtolower($pecah[1]);  //untuk command text

        $pecah5 = explode(':', $caption, 12);
        $katakex = strtolower($pecah5[10]);; //untuk command caption
        $katake41 = strtolower($pecah5[11]);

        $pecah6 = explode('-', $katakex, 2);
        $katake38 = strtolower($pecah6[0]);

        $pecah2 = explode(' ', $caption, 45);
        $katake1 = strtolower($pecah2[0]); //untuk command caption
        $katake4 = strtolower($pecah2[3]); // kata pertama setelah command caption
        $katake7 = strtolower($pecah2[6]); // kata kedua setelah command caption
        $katake10 = strtolower($pecah2[9]);
        $katake13 = strtolower($pecah2[12]);
        $katake17 = strtolower($pecah2[16]);
        $katake21 = strtolower($pecah2[20]);
        $katake26 = strtolower($pecah2[25]);
        $katake30 = strtolower($pecah2[29]);
        $katake34 = strtolower($pecah2[33]);

        $katake3 = strtolower($pecah2[2]);
        $katake6 = strtolower($pecah2[5]);
        $katake9 = strtolower($pecah2[8]);
        $katake12 = strtolower($pecah2[11]);
        $katake16 = strtolower($pecah2[15]);
        $katake20 = strtolower($pecah2[19]);
        $katake25 = strtolower($pecah2[24]);
        $katake29 = strtolower($pecah2[28]);
        $katake33 = strtolower($pecah2[32]);
        $katake37 = strtolower($pecah2[36]);
        $katake40 = strtolower($pecah2[39]);
        
        $pecah3 = explode(' ', $katake1, 3);
        $huruf1 = strtolower($pecah3[0]);

        $dir = dirname(__FILE__);
        $parent = explode("/", $dir, 3);
        $parentdir = strtolower($parent[1]);

    if (isset($sumber['text']) and $huruf1 = "/") {
        
        switch ($katapertama) {
        case '/start': 
        case '/start@namabot':
          $text = "Selamat datang <b>$nama</b>! Berikut ini menu yang tersedia. Untuk bantuan pilih /help.";
          $hasil = sendMessage($idpesan, $idchat, $text);  
        break;

        case '/help': 
        case '/help@namabot':
          $text = "Berikut menu yang tersedia:\n\n";
		  $text .= "/start untuk memulai bot\n";
          $text .= "/help info bantuan ini\n";	 	  
          $text .= "/format untuk melihat format pelaporan\n";
          $text .= "/laporan untuk melihat laporan harini\n";
          $text .= "/download untuk men-download detil laporan\n";
          $text .= "/download-tgl untuk men-download laporan yang lalu\n";
          $hasil = sendMessage($idpesan, $idchat, $text);
        break; 
		    
        case '/format': 
        case '/format@namabot':
              $text = "Lampirkan format berikut ini pada kolom caption foto yang dikirim \n\n =====================================\n\n /CLOSE\nSTO : \nCREW : \nTICKET : \nLAYANAN : \nCP PELANGGAN : \nNO. PELANGGAN : \nPANJANG DROP CORE : \nSN ONT : \nMAC STB : \nMATERIAL LAIN : \nJUMLAH : \n\n===================================== \n\n Catatan : \n - Hanya isikan <b> Panjang Drop Core </b> yang digunakan selama perbaikan, apabila tidak dilakukan tarik ulang isikan dengan -\n - Isikan <b> SN ONT </b> yang baru apabila terjadi penggantian ONT. Apabila tidak ada penggantian isikan dengan - \n - Isikan <b> MAC STB </b> yang baru apabila terjadi penggantian STB. Apabila tidak ada penggantian isikan dengan - \n - Untuk jenis material yang lain seperti Adapter ONT, Connector, Remote ONT dll. Isikan pada kolom material beserta jumlah yang digunakan pada kolom jumlah \n - Pastikan <b> Format </b> sesuai \n - Laporan yang terkirim akan langsung tersimpan";
              $hasil = sendMessage($idpesan, $idchat, $text);  
        break; 

        case '/laporan':
        case '/laporan@namabot':
            $servername = "localhost";
            $username = "root";
            $password = "1234567890";
            $dbname = "monitoring";
        
            $conn = new mysqli($servername, $username, $password, $dbname);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            print_r($namatabel);
            
            $resultan1 = mysqli_num_rows(mysqli_query($conn, "SELECT * from $namatabel where STO='MGO'"));
            $resultan2 = mysqli_num_rows(mysqli_query($conn, "SELECT * from $namatabel where STO='GSK'"));
            $resultan3 = mysqli_num_rows(mysqli_query($conn, "SELECT * from $namatabel where STO='TNS'"));
            $resultan4 = mysqli_num_rows(mysqli_query($conn, "SELECT * from $namatabel where STO='KNN'"));
            $resultan5 = mysqli_num_rows(mysqli_query($conn, "SELECT * from $namatabel where STO='KRP'"));
            $resultan6 = mysqli_num_rows(mysqli_query($conn, "SELECT * from $namatabel where STO='BBE'"));
            $resultan7 = mysqli_num_rows(mysqli_query($conn, "SELECT * from $namatabel where STO='KJR'"));
            $resultan8 = mysqli_num_rows(mysqli_query($conn, "SELECT * from $namatabel where STO='KBL'"));
            $resultan9 = mysqli_num_rows(mysqli_query($conn, "SELECT * from $namatabel where STO='LKI'"));
            $resultan10 = mysqli_num_rows(mysqli_query($conn, "SELECT * from $namatabel where STO='KLN'"));
            $resultan11 = mysqli_num_rows(mysqli_query($conn, "SELECT * from $namatabel where STO='LMG'"));
            $resultan12 = mysqli_num_rows(mysqli_query($conn, "SELECT * from $namatabel where STO='KPS'"));
            
            $text = "Berikut ini jumlah laporan gangguan selesai tiap STO hari ini : \n\n - MGO : ".$resultan1."\n - GSK : ".$resultan2."\n - TNS : ".$resultan3."\n - KNN : ".$resultan4."\n - KRP : ".$resultan5."\n - BBE : ".$resultan6."\n - KJR : ".$resultan7."\n - KBL : ".$resultan8."\n - LKI : ".$resultan9."\n - KLN : ".$resultan10."\n - LMG : ".$resultan11."\n - KPS : ".$resultan12;
              
            $hasil = sendMessage($idpesan, $idchat, $text);
        break;     
                            
        case '/download':
        case '/download@namabot':
            $dir = dirname(__FILE__);
            $parent = explode("/", $dir, 3);
            $parentdir = strtolower($parent[1]);

            $tahun = date("Y");
            $bulan = date("m");
            $tgl = date("d");
            
            $filefix = "Laporan-".date("d-m-Y").".xlsx";
            $file = "Laporan-".date("d-m-Y").".zip";
            $lap = "Laporan.xlsx";
            
            exec("php -f export-to-excel.php");

            $folderth = "/$parentdir/$tahun";
            $foldermo = "/$parentdir/$tahun/$bulan";
            $folderda = "/$parentdir/$tahun/$bulan/$tgl";
    
            if(file_exists($folderth)){
                exec("cd $folderth");
                if(file_exists($foldermo)){
                    exec("cd $foldermo");
                    if(file_exists($folderda)){
                        exec("cd $folderda");               
                    } else {
                        exec("mkdir $folderda");
                        exec("cd $folderda");
                    }
                } else {
                    exec("mkdir $foldermo");
                    exec("cd $foldermo");
                    exec("mkdir $folderda");
                    exec("cd $folderda");        
                } 
            } else {
                exec("mkdir $folderth");
                exec("cd $folderth");
                exec("mkdir $foldermo");
                exec("cd $foldermo");
                exec("mkdir $folderda");
                exec("cd $folderda");               
            }

            exec("mv /$parentdir/bot/$lap /$parentdir/$tahun/$bulan/$tgl/$filefix");
            exec("zip -r $file $folderda");

            $address = "/$parentdir/bot/$file";
            print_r($address);
            $post_fields = array('caption'   => 'Silahkan Download Laporan Hari Ini Diatas',
            'document'     => new CURLFile(realpath($address))
            );
            apiRequestMedia("sendDocument", $idchat, $post_fields);
        break;
        
        case '/downloadpertgl':
        case '/downloadpertgl@namabot':
            $dir = dirname(__FILE__);
            $parent = explode("/", $dir, 3);
            $parentdir = strtolower($parent[1]);

            $tahun = date("Y");
            $bulan = date("m");
            $tgl = $katakedua;
            
            $file = "Laporan-".$tgl."-".$bulan."-".$tahun.".zip";
            
            $folderbmo = "/$parentdir/Backup/$tahun/$bulan";

            $address = "$folderbmo/$file";

            if (file_exists($address)){
                print_r($address);
                $post_fields = array('caption'   => 'Silahkan Download Laporan Hari Ini Diatas',
                'document'     => new CURLFile(realpath($address))
                );
                apiRequestMedia("sendDocument", $idchat, $post_fields);
            } else {
                $text = "Backup tidak tersedia, periksa kembali tanggal yang anda inputkan.";
                $hasil = sendMessage($idpesan, $idchat, $text);
            }
        break;

        case '/downloadperbulan':
        case '/downloadperbulan@namabot':
            $dir = dirname(__FILE__);
            $parent = explode("/", $dir, 3);
            $parentdir = strtolower($parent[1]);

            $a = strtotime($katakedua);

            $tahun = date("Y");
            $bulan = date("m", $a);
            $tgl = 1;
            
            $file = "Laporan-".$bulan."-".$tahun.".zip";
            
            $folderbmo = "/$parentdir/Backup/$tahun/$bulan";
            exec("zip -r $file $folderbmo");
            $address = "/$parentdir/bot/$file";

            if (file_exists($address)){
                print_r($address);
                $post_fields = array('caption'   => 'Silahkan Download Laporan Bulan '.$bulan.' Diatas',
                'document'     => new CURLFile(realpath($address))
                );
                apiRequestMedia("sendDocument", $idchat, $post_fields);
            } else {
                $text = "Backup tidak tersedia, periksa kembali bulan yang anda inputkan.";
                $hasil = sendMessage($idpesan, $idchat, $text);
            }
        break;

        case '/downloadpertahun':
        case '/downloadpertahun@namabot':
            $dir = dirname(__FILE__);
            $parent = explode("/", $dir, 3);
            $parentdir = strtolower($parent[1]);

            $tahun = $katakedua;
            $bulan = 1;
            $tgl = 1;
            
            $file = "Laporan-".$tahun.".zip";
            
            $folderbth = "/$parentdir/Backup/$tahun";
            exec("zip -r $file $folderbth");
            $address = "/$parentdir/bot/$file";

            if (file_exists($address)){
                print_r($address);
                $post_fields = array('caption'   => 'Silahkan Download Laporan Tahun '.$tahun.' Diatas',
                'document'     => new CURLFile(realpath($address))
                );
                apiRequestMedia("sendDocument", $idchat, $post_fields);
            } else {
                $text = "Backup tidak tersedia, periksa kembali tahun yang anda inputkan.";
                $hasil = sendMessage($idpesan, $idchat, $text);
            }
        break;
            
        case '/CLOSE':
        case '/Close':
        case '/close': 
        case '/close@namabot':
                $text = "Maaf, format yang anda kirim tidak sesuai. Harap kirim <b>Foto</b> dengan <b>Format</b> pelaporan dalam <b>Caption-nya</b>. Untuk detail klik /format.";
                $hasil = sendMessage($idpesan, $idchat, $text);  
            break;

        }
        } elseif (isset($sumber['caption']) and $huruf1 = "/") {
            switch ($katake1){
                case '/CLOSE':
                case '/Close':
                case '/close':
                case '/close@namabot': 
                include "koneksi.php";
                        
                        $servername = "localhost";
                        $username = "root";
                        $password = "1234567890";
                        $dbname = "monitoring";
        
                        $conn = new mysqli($servername, $username, $password, $dbname);
                        if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                        }

                        $sto=$katake4;
                        $crew=$katake7;
                        $ticket=$katake10;
                        $layanan=$katake13;
                        $customer=$katake17;
                        $nocust=$katake21;
                        $dc=$katake26;
                        $ont=$katake30;
                        $stb=$katake34;
                        $dll=$katake38;
                        $jumlah=$katake41;
                        
                        if ($katake4 <> ":" and $katake7 <> ":" and $katake10 <> ":" and $katake13 <> ":" and $katake17 <> ":" and $katake21 <> ":" and $katake26 <> ":" and $katake30 <> ":" and $katake34 <> ":" and $katake38 <> ":" and $katake41 <> ":"){
                            print_r($gambar);
                            $sql = "INSERT INTO $namatabel (STO, CREW, TICKET, LAYANAN, CP_PELANGGAN, NO_PELANGGAN, DROP_CORE, SN_ONT, MAC_STB, MATERIAL_LAIN, JUMLAH, EVIDENCE) VALUES ( 
                                '$sto', 
                                '$crew', 
                                '$ticket',
                                '$layanan',
                                '$customer',
                                '$nocust',
                                '$dc',
                                '$ont',
                                '$stb',
                                '$dll',
                                '$jumlah',
                                '$gambar')";
                            
                            if ($conn->query($sql) === TRUE) {
                                apigetFilePath("getFile", $gambar);
                                $text = "Terimakasih $nama ($iduser), laporan telah diterima dan tersimpan";
                            } else {
                                echo "Error: " . $sql . "<br>" . $conn->error;
                                $text = "Maaf $nama ($iduser), laporan tidak sesuai format";
                            }
                        } else {
                            $text = "Maaf, format yang anda kirim tidak sesuai. Harap periksa <b>Spasi</b> tiap kata yang anda kirim. Untuk detail klik /format.";
                        }
                        $hasil = sendMessage($idpesan, $idchat, $text);
                        break;
        } 
        } else {
            echo ("Menerima lebih dari satu foto");
                    }
                }
}

if ($GLOBALS['debug']) {
            // hanya nampak saat metode poll dan debug = true;
            echo 'Pesan yang dikirim: '.$text.PHP_EOL;
            print_r($hasil);
}

echo 'Service Started!'.PHP_EOL.date('d-m-Y H:i:s').PHP_EOL;

function printUpdates($result)
{
    foreach ($result as $obj) {
        // echo $obj['message']['text'].PHP_EOL;
    processMessage($obj);
        $last_id = $obj['update_id'];
    }

    return $last_id;
}

//Mode Poll

/*$last_id = null;
while (true) {
    $result = getUpdates($last_id);
    if (!empty($result)) {
        echo '+';
        $last_id = printUpdates($result);
    } else {
        echo '-';
    }

    sleep(1);
}*/

//Mode Webhook

$content = file_get_contents("php://input");
$update = json_decode($content, true);

if (!$update) {
  exit;
} else {
  processMessage($update);
}

?>