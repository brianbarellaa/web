<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Dashboard ASO SBU</title>
  <meta name="description" content="Admin, Dashboard, Bootstrap, Bootstrap 4, Angular, AngularJS" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimal-ui" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">

  <!-- for ios 7 style, multi-resolution icon of 152x152 -->
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-barstyle" content="black-translucent">
  <link rel="apple-touch-icon" href="../assets/images/logo.png">
  <meta name="apple-mobile-web-app-title" content="Flatkit">
  <!-- for Chrome on Android, multi-resolution icon of 196x196 -->
  <meta name="mobile-web-app-capable" content="yes">
  <link rel="shortcut icon" sizes="196x196" href="../assets/images/logo.png">
  
  <!-- style -->
  <link rel="stylesheet" href="../assets/animate.css/animate.min.css" type="text/css" />
  <link rel="stylesheet" href="../assets/glyphicons/glyphicons.css" type="text/css" />
  <link rel="stylesheet" href="../assets/font-awesome/css/font-awesome.min.css" type="text/css" />
  <link rel="stylesheet" href="../assets/material-design-icons/material-design-icons.css" type="text/css" />

  <link rel="stylesheet" href="../assets/bootstrap/dist/css/bootstrap.min.css" type="text/css" />
  <!-- build:css ../assets/styles/app.min.css -->
  <link rel="stylesheet" href="../assets/styles/app.css" type="text/css" />
  <!-- endbuild -->
  <link rel="stylesheet" href="../assets/styles/font.css" type="text/css" />
</head>
<body>
<?php 
	session_start();
	if($_SESSION['status']!="login"){
		header("location:signin.php?pesan=belum_login");
	}
	?>
  <div class="app" id="app">

<!-- ############ LAYOUT START-->

  <!-- aside -->
  <div id="aside" class="app-aside modal fade nav-dropdown">
  	<!-- fluid app aside -->
    <div class="left navside dark dk" layout="column">
  	  <div class="navbar no-radius">
        <!-- brand -->
        <a class="navbar-brand">
        	<div ui-include="'../assets/images/logo.svg'"></div>
        	<img src="../assets/images/logo.png" alt="." class="hide">
        	<span class="hidden-folded inline">ASO SBU</span>
        </a>
        <!-- / brand -->
      </div>
      <div flex class="hide-scroll">
        <nav class="scroll nav-light">
          
            <ul class="nav" ui-nav>
              <li class="nav-header hidden-folded">
                <small class="text-muted">Main</small>
              </li>
              
              <li>
                <a href="dashboard.php" >
                  <span class="nav-icon">
                    <i class="material-icons">&#xe3fc;
                      <span ui-include="'../assets/images/i_0.svg'"></span>
                    </i>
                  </span>
                  <span class="nav-text">Dashboard</span>
                </a>
              </li>
          
              <li>
                <a href="static.php" >
                  <span class="nav-icon">
                    <i class="material-icons">&#xe8f0;
                      <span ui-include="'../assets/images/i_3.svg'"></span>
                    </i>
                  </span>
                  <span class="nav-text">Tabel</span>
                </a>
              </li>
              <li>
              <li>
                <a>
                  <span class="nav-caret">
                    <i class="fa fa-caret-down"></i>
                  </span>
                  <span class="nav-label hidden-folded">
                    <b class="label label-sm info">N</b>
                  </span>
                  <span class="nav-icon">
                    <i class="material-icons">&#xe1b8;
                      <span ui-include="'../assets/images/i_8.svg'"></span>
                    </i>
                  </span>
                  <span class="nav-text">STO</span>
                </a>
                <ul class="nav-sub">
                    <li>
                      <a href="mgo.php" >
                        <span class="nav-text">MGO</span>
                      </a>
                    </li>
                    <li>
                      <a href="gsk.php" >
                        <span class="nav-text">GSK</span>
                      </a>
                    </li><li>
                      <a href="tns.php" >
                        <span class="nav-text">TNS</span>
                      </a>
                    </li>
                    <li>
                      <a href="knn.php" >
                        <span class="nav-text">KNN</span>
                      </a>
                    </li>
                    <li>
                      <a href="krp.php" >
                        <span class="nav-text">KRP</span>
                      </a>
                    </li>
                    <li>
                      <a href="bbe.php" >
                        <span class="nav-text">BBE</span>
                      </a>
                    </li>
                    <li>
                      <a href="kjr.php" >
                        <span class="nav-text">KJR</span>
                      </a>
                    </li>
                    <li>
                      <a href="kbl.php" >
                        <span class="nav-text">KBL</span>
                      </a>
                    </li>
                    <li>
                      <a href="lki.php" >
                        <span class="nav-text">LKI</span>
                      </a>
                    </li>
                    <li>
                      <a href="kln.php" >
                        <span class="nav-text">KLN</span>
                      </a>
                    </li>
                    <li>
                      <a href="lmg.php" >
                        <span class="nav-text">LMG</span>
                      </a>
                    </li>
                    <li>
                      <a href="kps.php" >
                        <span class="nav-text">KPS</span>
                      </a>
                    </li>
                  
                  </ul>
              </li>            
            </ul>
        </nav>
    </div>
      <div flex-no-shrink class="b-t">
        <div class="nav-fold">
        	<a href="signout.php">
        	    <span class="pull-left">
        	      <img src="../assets/images/logo.png" alt="..." class="w-40 img-circle">
        	    </span>
        	    <span class="clear hidden-folded p-x">
        	      <span class="block _500">Keluar</span>
        	      
        	    </span>
        	</a>
        </div>
      </div>
    </div>
  </div>
  <!-- / -->
  
  <!-- content -->
  <div id="content" class="app-content box-shadow-z0" role="main">
    <div class="app-header white box-shadow">
        <div class="navbar">
            <!-- Open side - Naviation on mobile -->
            <a data-toggle="modal" data-target="#aside" class="navbar-item pull-left hidden-lg-up">
              <i class="material-icons">&#xe5d2;</i>
            </a>
            <!-- / -->
        
            <!-- Page title - Bind to $state's title -->
            <div class="navbar-item pull-left h5" ng-bind="$state.current.data.title" id="pageTitle"></div>
        
            <!-- navbar right -->
            <ul class="nav navbar-nav pull-right">
              <li class="nav-item dropdown">
                <a class="nav-link clear" href data-toggle="dropdown">
                  <span class="avatar w-32">
                    <img src="../assets/images/logo.png" alt="...">
                    <i class="on b-white bottom"></i>
                  </span>
                </a>
                <div ui-include="'../views/blocks/dropdown.user.php'"></div>
              </li>
              <li class="nav-item hidden-md-up">
                <a class="nav-link" data-toggle="collapse" data-target="#collapse">
                  <i class="material-icons">&#xe5d4;</i>
                </a>
              </li>
            </ul>
            <!-- / navbar right -->
        
            <!-- navbar collapse -->
            <div class="collapse navbar-toggleable-sm" id="collapse">
              <div ui-include="'../views/blocks/navbar.form.right.php'"></div>
              <!-- link and dropdown -->
           
              <!-- / -->
            </div>
            <!-- / navbar collapse -->
        </div>
    </div>
    <div class="app-footer">
      <div class="p-a text-xs">
        <div class="pull-right text-muted">
          &copy; Developed by <strong>Brian Barella</strong> <span class="hidden-xs-down">- Built with Love</span>
          <a ui-scroll-to="content"><i class="fa fa-long-arrow-up p-x-sm"></i></a>
        </div>
      </div>
    </div>
    <div ui-view class="app-body" id="view">

<?php

    $servername = "localhost";
    $username = "bot";
    $password = "1234567890";
    $dbname = "monitoring";
    error_reporting(E_ERROR | E_PARSE);      
    $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
    }
    $namatabel = "Laporan".date("dmY");

        $dcw = mysqli_query($conn, "SELECT SUM(DROP_CORE) FROM $namatabel WHERE STO='KPS' AND DROP_CORE<>'-'");
        while($row = mysqli_fetch_array($dcw)){
          $dc = $row['SUM(DROP_CORE)'];
        }

        $ontw = mysqli_query($conn, "SELECT COUNT(SN_ONT) FROM $namatabel WHERE STO='KPS' AND SN_ONT<>'-'");
        while($row = mysqli_fetch_array($ontw)){
          $ont = $row['COUNT(SN_ONT)'];
        }

        $stbw = mysqli_query($conn, "SELECT COUNT(MAC_STB) FROM $namatabel WHERE STO='KPS' AND MAC_STB<>'-'");
        while($row = mysqli_fetch_array($stbw)){
          $stb = $row['COUNT(MAC_STB)'];
        }

        $mlw = mysqli_query($conn, "SELECT COUNT(MATERIAL_LAIN) FROM $namatabel WHERE STO='KPS' AND MATERIAL_LAIN<>'-'");
        while($row = mysqli_fetch_array($mlw)){
          $ml = $row['COUNT(MATERIAL_LAIN)'];
        }

        $today = "$dc, $ont, $stb, $ml";

        $pdc = $dc / 100;
        $tot = $ont + $pdc + $stb + $ml;
        $ppdc = $pdc / $tot;
        $pont = $ont / $tot;
        $pstb = $stb / $tot;
        $pml = $ml / $tot;

        $a=date("d");
        $b=1;
        
        $DC = 0;
        $ONT = 0;
        $STB = 0;
        $ML = 0;

        $dca = 0;
        $onta = 0;
        $stba = 0;
        $mla = 0;
        
        while($b<=$a){
          $namatabel2="Laporan".$b.date("mY");

          $sqldc = mysqli_query($conn, "SELECT SUM(DROP_CORE) FROM $namatabel2 WHERE STO='KPS' AND DROP_CORE<>'-'");
          
          while($row = @mysqli_fetch_array($sqldc)){
            $DC = $row['SUM(DROP_CORE)'];
            $dca = $dca + $DC;
          }
          $sqlont = mysqli_query($conn, "SELECT COUNT(SN_ONT) FROM $namatabel2 WHERE STO='KPS' AND SN_ONT<>'-'");
          
          while($row = @mysqli_fetch_array($sqlont)){
            $ONT = $row['COUNT(SN_ONT)'];
            $onta = $onta + $ONT;
          }
          $sqlstb = mysqli_query($conn, "SELECT COUNT(MAC_STB) FROM $namatabel2 WHERE STO='KPS' AND MAC_STB<>'-'");
          
          while($row = @mysqli_fetch_array($sqlstb)){
            $STB = $row['COUNT(MAC_STB)'];
            $stba = $stba + $STB;
          }
          $sqlml = mysqli_query($conn, "SELECT COUNT(MATERIAL_LAIN) FROM $namatabel2 WHERE STO='KPS' AND MATERIAL_LAIN<>'-'");
          
          while($row = @mysqli_fetch_array($sqlml)){
            $ML = $row['COUNT(MATERIAL_LAIN)'];
            $mla = $mla + $ML;
          }
          $b++;
          }

        $seminggu = $a - 7;
        
        $TC = 0;
        $DC = 0;
        $ONT = 0;
        $STB = 0;
        $ML = 0;

        $stca = 0;
        $sdca = 0;
        $sonta = 0;
        $sstba = 0;
        $smla = 0;

        while($seminggu<=$a){
          $namatabel2="Laporan".$seminggu.date("mY");

          $sqltc = mysqli_query($conn, "SELECT COUNT(TICKET) FROM $namatabel2 WHERE STO='KPS' AND TICKET<>'-'");
          
          while($row = @mysqli_fetch_array($sqltc)){
            $TC = $row['COUNT(TICKET)'];
          }
          $stca = $stca.", "."[".$seminggu.", ".$TC."]";
          $STCA = explode("0, ", $stca, 2);

          $sqldc = mysqli_query($conn, "SELECT SUM(DROP_CORE) FROM $namatabel2 WHERE STO='KPS' AND DROP_CORE<>'-'");
          
          while($row = @mysqli_fetch_array($sqldc)){
            $DC = $row['SUM(DROP_CORE)'];
          }
          $sdca = $sdca.", "."[".$seminggu.", ".$DC."]";
          $SDCA = explode("0, ", $sdca, 2);

          $sqlont = mysqli_query($conn, "SELECT COUNT(SN_ONT) FROM $namatabel2 WHERE STO='KPS' AND SN_ONT<>'-'");
          
          while($row = @mysqli_fetch_array($sqlont)){
            $ONT = $row['COUNT(SN_ONT)'];
          }
          $sonta = $sonta.", "."[".$seminggu.", ".$ONT."]";
          $SONTA = explode("0, ", $sonta, 2);

          $sqlstb = mysqli_query($conn, "SELECT COUNT(MAC_STB) FROM $namatabel2 WHERE STO='KPS' AND MAC_STB<>'-'");
          
          while($row = @mysqli_fetch_array($sqlstb)){
            $STB = $row['COUNT(MAC_STB)'];
          }
          $sstba = $sstba.", "."[".$seminggu.", ".$STB."]";
          $SSTBA = explode("0, ", $sstba, 2);

          $sqlml = mysqli_query($conn, "SELECT COUNT(MATERIAL_LAIN) FROM $namatabel2 WHERE STO='KPS' AND MATERIAL_LAIN<>'-'");
          
          while($row = @mysqli_fetch_array($sqlml)){
            $ML = $row['COUNT(MATERIAL_LAIN)'];
          }
          $smla = $smla.", "."[".$seminggu.", ".$ML."]";
          $SMLA = explode("0, ", $smla, 2);

          $seminggu++;
          }

          $mingguini = "$sdca, $sonta, $sstba, $smla";

?>

<!-- ############ PAGE START-->
<div class="padding">
    <div class="row">
      <div class="col-sm-6 col-md-4 col-lg-3">
        <div class="box p-a">
          <div class="pull-left m-r">
            <span class="w-40 warn text-center rounded">
              <i class="material-icons">&#xe0d9;</i>
            </span>
          </div>
          <div class="clear">
            <h4 class="m-a-0 text-md"><a href><?php echo($dc);?> <span class="text-sm">meter Drop Core</span></a></h4>
            <small class="text-muted">Hari ini</small>
          </div>
        </div>
      </div>
      <div class="col-sm-6 col-md-4 col-lg-3">
        <div class="box-color p-a primary">
          <div class="pull-right m-l">
            <span class="w-40 dker text-center rounded">
              <i class="material-icons">&#xe1e2;</i>
            </span>
          </div>
          <div class="clear">
            <h4 class="m-a-0 text-md"><a href><?php echo($ont);?> <span class="text-sm">buah ONT</span></a></h4>
            <small class="text-muted">Hari ini</small>
          </div>
        </div>
      </div>
      <div class="col-sm-6 col-md-4 col-lg-3">
        <div class="box p-a">
          <div class="pull-right m-l">
            <span class="w-40 accent text-center rounded">
              <i class="material-icons">&#xe039;</i>
            </span>
          </div>
          <div class="clear">
            <h4 class="m-a-0 text-md"><a href><?php echo($stb);?> <span class="text-sm">buah STB</span></a></h4>
            <small class="text-muted">Hari ini</small>
          </div>
        </div>
      </div>
      <div class="col-sm-6 col-md-4 col-lg-3">
        <div class="box-color p-a accent">
          <div class="pull-left m-r">
            <span class="w-40 dker text-center rounded">
              <i class="material-icons">&#xe39d;</i>
            </span>
          </div>
          <div class="clear">
            <h4 class="m-a-0 text-md"><a href><?php echo($ml);?> <span class="text-sm">buah Material Lain</span></a></h4>
            <small class="text-muted">Hari ini</small>
          </div>
        </div>
      </div>
      <div class="col-sm-6 col-md-4 col-lg-3">
        <div class="box-color p-a accent">
          <div class="pull-right m-l">
            <span ui-jp="sparkline" ui-options="[70,30], {type:'pie', height:36, sliceColors:['#fff','transparent']}" class="sparkline inline"></span>
          </div>
          <div class="clear">
            <h4 class="m-a-0 text-md"><a href><?php echo($dca);?><span class="text-sm"> meter Drop Core</span></a></h4>
            <small class="text-muted">Bulan ini</small>
          </div>
        </div>
      </div>
      <div class="col-sm-6 col-md-4 col-lg-3">
        <div class="box p-a">
          <div class="pull-left m-r">
            <span ui-jp="sparkline" ui-refresh="app.setting.color" ui-options="[40,60], {type:'pie', height:36, sliceColors:['#f1f2f3','#0cc2aa']}" class="sparkline inline"></span>
          </div>
          <div class="clear">
            <h4 class="m-a-0 text-md"><a href><?php echo($onta);?> <span class="text-sm">buah ONT</span></a></h4>
            <small class="text-muted">Bulan ini</small>
          </div>
        </div>
      </div>
      <div class="col-sm-6 col-md-4 col-lg-3">
        <div class="box-color p-a warn">
          <div class="pull-left m-r">
            <span class="m-y-sm inline" ui-jp="sparkline" ui-options="[[2,8],[4,6],[6,4],[8,2],[10,0],[8,2],[6,4],[4,6],[2,8]], {type:'bar', height:24, barWidth:4, barSpacing:2, stackedBarColor:['#fff', 'rgba(255,255,255,0.2)']}"></span>
          </div>
          <div class="clear">
            <h4 class="m-a-0 text-md"><a href><?php echo($stba);?> <span class="text-sm">buah STB</span></a></h4>
            <small class="text-muted">Bulan ini</small>
          </div>
        </div>
      </div>
      <div class="col-sm-6 col-md-4 col-lg-3">
        <div class="box p-a">
          <div class="pull-right m-l">
            <span class="m-y-sm inline" ui-jp="sparkline" ui-refresh="app.setting.color" ui-options="[1,1,0,1,-1,-1,1,-1,0,0,1,1], {type:'tristate', height:24, width: 'auto', type: 'tristate', colorMap: {'-1': '#fcc100', '1': '#0cc2aa'}}"></span>
          </div>
          <div class="clear">
            <h4 class="m-a-0 text-md"><a href><?php echo($mla);?> <span class="text-sm">buah Material Lain</span></a></h4>
            <small class="text-muted">Bulan ini</small>
          </div>
        </div>
      </div>
    </div>
    
    <div class="row">
      <div class="col-sm-6 col-md-4">
        <div class="box">
          <div class="box-header">
            <h3>Rasio Hari Ini</h3>
            <small>Perbandingan Penggunaan Material Hari Ini</small>
          </div>
          <div class="box-body">
            <div ui-jp="plot" ui-refresh="app.setting.color" ui-options="
              [{data: <?php echo($ppdc);?>, label:&#x27;Drop Core Per 100 m&#x27;}, {data: <?php echo($pont);?>, label: &#x27;ONT&#x27;}, {data: <?php echo($pstb);?>, label: &#x27;STB&#x27;}, {data: <?php echo($pml);?>, label: &#x27;Material Lain&#x27;}],
              {
                series: { pie: { show: true, innerRadius: 0.6, stroke: { width: 0 }, label: { show: true, threshold: 0.05 } } },
                legend: {backgroundColor: 'transparent'},
                colors: ['#0cc2aa','#fcc100'],
                grid: { hoverable: true, clickable: true, borderWidth: 0, color: 'rgba(120,120,120,0.5)' },   
                tooltip: true,
                tooltipOpts: { content: '%s: %p.0%' }
              }
            " style="height:200px"></div>
          </div>
        </div>
      </div>
      <div class="col-sm-6 col-md-4">
        <div class="box">
          <div class="box-header">
            <h3>Jumlah Ticket Selesai</h3>
            <small>Data Terkumpul Dalam Satu Minggu</small>
          </div>
          <div class="box-body">
            <div ui-jp="plot" ui-refresh="app.setting.color" ui-options="
              [
                { data: [<?php print_r($STCA[1]); ?>], 
                  points: { show: true, radius: 3}, 
                  lines: { show: true, lineWidth: 1} 
                },
                { data: [<?php print_r($STCA[1]); ?>], 
                  bars: { show: true, barWidth: 0.4, align: 'center', lineWidth: 1, fillColor: { colors: [{ opacity: 0.6 }, { opacity: 1}] } } 
                }
              ], 
              {
                colors: ['#fcc100','#0cc2aa'],
                series: { shadowSize: 3 },
                xaxis: { show: true, font: { color: '#ccc' }, position: 'bottom' },
                yaxis:{ show: true, font: { color: '#ccc' }},
                grid: { hoverable: true, clickable: true, borderWidth: 0, color: 'rgba(120,120,120,0.5)' },
                tooltip: true,
                tooltipOpts: { content: 'Pada tanggal %x.0 ada %y.0 buah tiket selesai',  defaultTheme: false, shifts: { x: 0, y: -40 } }
              }
            " style="height:200px" >
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-6 col-md-4">
        <div class="box">
          <div class="box-header">
            <h3>Jumlah Drop Core</h3>
            <small>Data Terkumpul Dalam Satu Minggu</small>
          </div>
          <div class="box-body">
            <div ui-jp="plot" ui-refresh="app.setting.color" ui-options="
              [
                { data: [<?php print_r($SDCA[1]); ?>], 
                  points: { show: true, radius: 3}, 
                  lines: { show: true, lineWidth: 1} 
                },
                { data: [<?php print_r($SDCA[1]); ?>], 
                  bars: { show: true, barWidth: 0.4, align: 'center', lineWidth: 1, fillColor: { colors: [{ opacity: 0.6 }, { opacity: 1}] } } 
                }
              ], 
              {
                colors: ['#fcc100','#0cc2aa'],
                series: { shadowSize: 3 },
                xaxis: { show: true, font: { color: '#ccc' }, position: 'bottom' },
                yaxis:{ show: true, font: { color: '#ccc' }},
                grid: { hoverable: true, clickable: true, borderWidth: 0, color: 'rgba(120,120,120,0.5)' },
                tooltip: true,
                tooltipOpts: { content: 'Pada tanggal %x.0 ada %y.0 meter kabel',  defaultTheme: false, shifts: { x: 0, y: -40 } }
              }
            " style="height:200px" >
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-6 col-md-4">
        <div class="box">
          <div class="box-header">
            <h3>Jumlah ONT</h3>
            <small>Data Terkumpul Dalam Satu Minggu</small>
          </div>
          <div class="box-body">
            <div ui-jp="plot" ui-refresh="app.setting.color" ui-options="
              [
                { data: [<?php print_r($SONTA[1]); ?>], 
                  points: { show: true, radius: 3}, 
                  lines: { show: true, lineWidth: 1} 
                },
                { data: [<?php print_r($SONTA[1]); ?>], 
                  bars: { show: true, barWidth: 0.4, align: 'center', lineWidth: 1, fillColor: { colors: [{ opacity: 0.6 }, { opacity: 1}] } } 
                }
              ], 
              {
                colors: ['#fcc100','#0cc2aa'],
                series: { shadowSize: 3 },
                xaxis: { show: true, font: { color: '#ccc' }, position: 'bottom' },
                yaxis:{ show: true, font: { color: '#ccc' }},
                grid: { hoverable: true, clickable: true, borderWidth: 0, color: 'rgba(120,120,120,0.5)' },
                tooltip: true,
                tooltipOpts: { content: 'Pada tanggal %x.0 ada %y.0 buah material',  defaultTheme: false, shifts: { x: 0, y: -40 } }
              }
            " style="height:200px" >
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-6 col-md-4">
        <div class="box">
          <div class="box-header">
            <h3>Jumlah STB</h3>
            <small>Data Terkumpul Dalam Satu Minggu</small>
          </div>
          <div class="box-body">
            <div ui-jp="plot" ui-refresh="app.setting.color" ui-options="
              [
                { data: [<?php print_r($SSTBA[1]); ?>], 
                  points: { show: true, radius: 3}, 
                  lines: { show: true, lineWidth: 1} 
                },
                { data: [<?php print_r($SSTBA[1]); ?>], 
                  bars: { show: true, barWidth: 0.4, align: 'center', lineWidth: 1, fillColor: { colors: [{ opacity: 0.6 }, { opacity: 1}] } } 
                }
              ], 
              {
                colors: ['#fcc100','#0cc2aa'],
                series: { shadowSize: 3 },
                xaxis: { show: true, font: { color: '#ccc' }, position: 'bottom' },
                yaxis:{ show: true, font: { color: '#ccc' }},
                grid: { hoverable: true, clickable: true, borderWidth: 0, color: 'rgba(120,120,120,0.5)' },
                tooltip: true,
                tooltipOpts: { content: 'Pada tanggal %x.0 ada %y.0 buah material',  defaultTheme: false, shifts: { x: 0, y: -40 } }
              }
            " style="height:200px" >
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-6 col-md-4">
        <div class="box">
          <div class="box-header">
            <h3>Jumlah Material Lain</h3>
            <small>Data Terkumpul Dalam Satu Minggu</small>
          </div>
          <div class="box-body">
            <div ui-jp="plot" ui-refresh="app.setting.color" ui-options="
              [
                { data: [<?php print_r($SMLA[1]); ?>], 
                  points: { show: true, radius: 3}, 
                  lines: { show: true, lineWidth: 1} 
                },
                { data: [<?php print_r($SMLA[1]); ?>], 
                  bars: { show: true, barWidth: 0.4, align: 'center', lineWidth: 1, fillColor: { colors: [{ opacity: 0.6 }, { opacity: 1}] } } 
                }
              ], 
              {
                colors: ['#fcc100','#0cc2aa'],
                series: { shadowSize: 3 },
                xaxis: { show: true, font: { color: '#ccc' }, position: 'bottom' },
                yaxis:{ show: true, font: { color: '#ccc' }},
                grid: { hoverable: true, clickable: true, borderWidth: 0, color: 'rgba(120,120,120,0.5)' },
                tooltip: true,
                tooltipOpts: { content: 'Pada tanggal %x.0 ada %y.0 buah material',  defaultTheme: false, shifts: { x: 0, y: -40 } }
              }
            " style="height:200px" >
            </div>
          </div>
        </div>
      </div>
    </div>
</div>

<!-- ############ PAGE END-->

    </div>
  </div>
  <!-- / -->

  <!-- theme switcher -->
  <div id="switcher">
    <div class="switcher box-color dark-white text-color" id="sw-theme">
      <a href ui-toggle-class="active" target="#sw-theme" class="box-color warn text-color sw-btn">
        <i class="fa fa-gear"></i>
      </a>
      <div class="box-header">
        <h2>Theme Switcher</h2>
      </div>
      <div class="box-divider"></div>
      <div class="box-body">  
        <div data-target="bg" class="text-u-c text-center _600 clearfix">
          <label class="p-a col-xs-6 light pointer m-a-0">
            <input type="radio" name="theme" value="" hidden>
            Light
          </label>
          <label class="p-a col-xs-6 black pointer m-a-0">
            <input type="radio" name="theme" value="black" hidden>
            Dark
          </label>
        </div>
      </div>
    </div>
  </div>
  <!-- / -->

<!-- ############ LAYOUT END-->

  </div>
<!-- build:js scripts/app.php.js -->
<!-- jQuery -->
  <script src="../libs/jquery/jquery/dist/jquery.js"></script>
<!-- Bootstrap -->
  <script src="../libs/jquery/tether/dist/js/tether.min.js"></script>
  <script src="../libs/jquery/bootstrap/dist/js/bootstrap.js"></script>
<!-- core -->
  <script src="../libs/jquery/underscore/underscore-min.js"></script>
  <script src="../libs/jquery/jQuery-Storage-API/jquery.storageapi.min.js"></script>
  <script src="../libs/jquery/PACE/pace.min.js"></script>

  <script src="scripts/config.lazyload.js"></script>

  <script src="scripts/palette.js"></script>
  <script src="scripts/ui-load.js"></script>
  <script src="scripts/ui-jp.js"></script>
  <script src="scripts/ui-include.js"></script>
  <script src="scripts/ui-device.js"></script>
  <script src="scripts/ui-form.js"></script>
  <script src="scripts/ui-nav.js"></script>
  <script src="scripts/ui-screenfull.js"></script>
  <script src="scripts/ui-scroll-to.js"></script>
  <script src="scripts/ui-toggle-class.js"></script>

  <script src="scripts/app.js"></script>

  <!-- ajax -->
  <script src="../libs/jquery/jquery-pjax/jquery.pjax.js"></script>
  <script src="scripts/ajax.js"></script>
<!-- endbuild -->
</body>
</html>
