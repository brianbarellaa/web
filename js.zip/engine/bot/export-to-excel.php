<?php

$servername = "localhost";
$username = "root";
$password = "1234567890";
$dbname = "monitoring";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$namatabel = "Laporan".date("dmY");;
# MENGAMBIL DATA DARI DATABASE mysqli
$result = mysqli_query($conn, "SELECT * FROM $namatabel ORDER BY STO ASC");


/** Include PHPExcel */
require_once dirname(__FILE__) . '/Classes/PHPExcel.php';

$objPHPExcel = new PHPExcel();

// Set document properties
$objPHPExcel->getProperties()->setCreator("Assurance BOT")
							->setLastModifiedBy("Assurance BOT")
							->setTitle("Laporan")
							->setSubject("Lapor")
							->setDescription("Data Gangguan Hari ini");
// mulai dari baris ke 2
$row = 2;

// Tulis judul tabel
$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.$row, 'Nomor')
            ->setCellValue('B'.$row, 'STO')
            ->setCellValue('C'.$row, 'CREW')
            ->setCellValue('D'.$row, 'TICKET')
            ->setCellValue('E'.$row, 'LAYANAN')
            ->setCellValue('F'.$row, 'CP PELANGGAN')
            ->setCellValue('G'.$row, 'NO PELANGGAN')
            ->setCellValue('H'.$row, 'PANJANG DROP CORE')
            ->setCellValue('I'.$row, 'SN ONT')
            ->setCellValue('J'.$row, 'MAC STB')
            ->setCellValue('K'.$row, 'MATERIAL LAIN')
            ->setCellValue('L'.$row, 'JUMLAH')
            ->setCellValue('M'.$row, 'EVIDENCE');
$nomor 	= 1; // set nomor urut = 1;

$row++; // pindah ke row bawahnya. (ke row 2)

// lakukan perulangan untuk menuliskan data siswa
while( $data = mysqli_fetch_array($result)){
	$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.$row,  $nomor )
            ->setCellValue('B'.$row, $data['STO'] )
            ->setCellValue('C'.$row, $data['CREW'] )
            ->setCellValue('D'.$row, $data['TICKET'] )
            ->setCellValue('E'.$row, $data['LAYANAN'] )
            ->setCellValue('F'.$row, $data['CP_PELANGGAN'] )
            ->setCellValue('G'.$row, $data['NO_PELANGGAN'] )
            ->setCellValue('H'.$row, $data['DROP_CORE'] )
            ->setCellValue('I'.$row, $data['SN_ONT'] )
            ->setCellValue('J'.$row, $data['MAC_STB'] )
            ->setCellValue('K'.$row, $data['MATERIAL_LAIN'] )
            ->setCellValue('L'.$row, $data['JUMLAH'] )
            ->setCellValue('M'.$row, $data['EVIDENCE'] );
	$row++; // pindah ke row bawahnya ($row + 1)
	$nomor++;
}

$nomor2 = $nomor + 1;
$koor = "A2:M$nomor2";
$objPHPExcel->getSheet(0)->getStyle($koor)->getBorders()->getAllBorders()
->setBorderStyle(PHPExcel_Style_Border::BORDER_THICK);

$objPHPExcel->getSheet(0)->getColumnDimension('A')->setAutoSize(true);
$objPHPExcel->getSheet(0)->getColumnDimension('B')->setAutoSize(true);
$objPHPExcel->getSheet(0)->getColumnDimension('C')->setAutoSize(true);
$objPHPExcel->getSheet(0)->getColumnDimension('D')->setAutoSize(true);
$objPHPExcel->getSheet(0)->getColumnDimension('E')->setAutoSize(true);
$objPHPExcel->getSheet(0)->getColumnDimension('F')->setAutoSize(true);
$objPHPExcel->getSheet(0)->getColumnDimension('G')->setAutoSize(true);
$objPHPExcel->getSheet(0)->getColumnDimension('H')->setAutoSize(true);
$objPHPExcel->getSheet(0)->getColumnDimension('I')->setAutoSize(true);
$objPHPExcel->getSheet(0)->getColumnDimension('J')->setAutoSize(true);
$objPHPExcel->getSheet(0)->getColumnDimension('K')->setAutoSize(true);
$objPHPExcel->getSheet(0)->getColumnDimension('L')->setAutoSize(true);
$objPHPExcel->getSheet(0)->getColumnDimension('M')->setAutoSize(true);


// Rename worksheet
$objPHPExcel->getActiveSheet()->setTitle('Laporan Gangguan Hari Ini');

// Set sheet yang aktif adalah index pertama, jadi saat dibuka akan langsung fokus ke sheet pertama
$objPHPExcel->setActiveSheetIndex(0);




// Simpan ke Excel 2007
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
$objWriter->save('Laporan.xlsx');

// Simpan ke Excel 2003
/* $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save('data.xls'); */


$objWriter->save('php://output');
exit;


/* 
// Download (Excel2003)
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="data.xls"');
header('Cache-Control: max-age=0');
// If you're serving to IE 9, then the following may be needed
header('Cache-Control: max-age=1');
// If you're serving to IE over SSL, then the following may be needed
header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
header ('Pragma: public'); // HTTP/1.0
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5'); 

$objWriter->save('php://output');
exit;
 */
?>