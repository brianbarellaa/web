<?php 

// menghubungkan dengan koneksi
    $servername = "localhost";
    $username = "bot";
    $password = "1234567890";
    $dbname = "user";
        
    $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
    }

    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $password = "subdomain/".$_POST['password']."/extras";
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);

    // menyiapkan query
    $sql = "INSERT INTO userdata (USERNAME, EMAIL, PASSWORDA) VALUES ('$username', '$email', '$password')";

$pecah = explode("@", $email, 2);
$emaildiv = strtolower($pecah[1]);

if($emaildiv != "telkom.co.id"){
    print_r($emaildiv);
    //header("location:telkom.php");
} else {
    if ($conn->query($sql) === TRUE) {
        header("location:signin.php");
    } 
}  

?>