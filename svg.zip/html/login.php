<?php 
// mengaktifkan session php
session_start();

// menghubungkan dengan koneksi
    $servername = "localhost";
    $username = "bot";
    $password = "1234567890";
    $dbname = "user";
        
    $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
    }

// menangkap data yang dikirim dari form
$email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
$password = "subdomain/".$_POST['password']."/extras";

// menyeleksi data admin dengan username dan password yang sesuai
$data = mysqli_query($conn,"SELECT * FROM userdata WHERE EMAIL='$email' AND PASSWORDA='$password'");

// menghitung jumlah data yang ditemukan
$cek = mysqli_num_rows($data);

if($cek > 0){
	$_SESSION['username'] = $username;
	$_SESSION['status'] = "login";
	header("location:dashboard.php");
}else{
    //header("location:signin.php?pesan=gagal");
    echo($password.$email);
}
?>