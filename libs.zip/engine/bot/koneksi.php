<?
	$connect=mysqli_connect("localhost","root2","1234567890","monitoring");
	mysqli_select_db("monitoring") or die ("Connect Failed !! : ".mysqli_error()); 
?>